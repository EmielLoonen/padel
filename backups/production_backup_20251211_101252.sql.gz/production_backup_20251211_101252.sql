--
-- PostgreSQL database dump
--

\restrict eSQCujzN6D5Yuwz2HZBtHVewwznkotxOVjvu80FpVBvkp6Skr7GOqLV23gFZS46

-- Dumped from database version 17.7 (178558d)
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.sets DROP CONSTRAINT IF EXISTS sets_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sets DROP CONSTRAINT IF EXISTS sets_court_id_fkey;
ALTER TABLE IF EXISTS ONLY public.set_scores DROP CONSTRAINT IF EXISTS set_scores_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.set_scores DROP CONSTRAINT IF EXISTS set_scores_set_id_fkey;
ALTER TABLE IF EXISTS ONLY public.set_scores DROP CONSTRAINT IF EXISTS set_scores_guest_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rsvps DROP CONSTRAINT IF EXISTS rsvps_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rsvps DROP CONSTRAINT IF EXISTS rsvps_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rsvps DROP CONSTRAINT IF EXISTS rsvps_court_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.guests DROP CONSTRAINT IF EXISTS guests_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.guests DROP CONSTRAINT IF EXISTS guests_court_id_fkey;
ALTER TABLE IF EXISTS ONLY public.guests DROP CONSTRAINT IF EXISTS guests_added_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.courts DROP CONSTRAINT IF EXISTS courts_session_id_fkey;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.sets_created_by_id_idx;
DROP INDEX IF EXISTS public.sets_court_id_idx;
DROP INDEX IF EXISTS public.set_scores_user_id_idx;
DROP INDEX IF EXISTS public.set_scores_set_id_idx;
DROP INDEX IF EXISTS public.set_scores_guest_id_idx;
DROP INDEX IF EXISTS public.sessions_date_time_idx;
DROP INDEX IF EXISTS public.sessions_created_by_id_idx;
DROP INDEX IF EXISTS public.rsvps_user_id_idx;
DROP INDEX IF EXISTS public.rsvps_session_id_user_id_key;
DROP INDEX IF EXISTS public.rsvps_session_id_idx;
DROP INDEX IF EXISTS public.rsvps_court_id_idx;
DROP INDEX IF EXISTS public.notifications_user_id_read_idx;
DROP INDEX IF EXISTS public.notifications_created_at_idx;
DROP INDEX IF EXISTS public.guests_session_id_idx;
DROP INDEX IF EXISTS public.guests_court_id_idx;
DROP INDEX IF EXISTS public.guests_added_by_id_idx;
DROP INDEX IF EXISTS public.courts_session_id_idx;
DROP INDEX IF EXISTS public.courts_session_id_court_number_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.sets DROP CONSTRAINT IF EXISTS sets_pkey;
ALTER TABLE IF EXISTS ONLY public.set_scores DROP CONSTRAINT IF EXISTS set_scores_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.rsvps DROP CONSTRAINT IF EXISTS rsvps_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.guests DROP CONSTRAINT IF EXISTS guests_pkey;
ALTER TABLE IF EXISTS ONLY public.courts DROP CONSTRAINT IF EXISTS courts_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.sets;
DROP TABLE IF EXISTS public.set_scores;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.rsvps;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.guests;
DROP TABLE IF EXISTS public.courts;
DROP TABLE IF EXISTS public._prisma_migrations;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: courts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courts (
    id text NOT NULL,
    session_id text NOT NULL,
    court_number integer NOT NULL,
    start_time text NOT NULL,
    duration integer DEFAULT 60 NOT NULL,
    max_players integer DEFAULT 4 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cost numeric(10,2)
);


--
-- Name: guests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guests (
    id text NOT NULL,
    court_id text,
    name text NOT NULL,
    added_by_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    session_id text NOT NULL,
    status text DEFAULT 'yes'::text NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    user_id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    session_id text,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: rsvps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rsvps (
    id text NOT NULL,
    session_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    court_id text
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "time" text NOT NULL,
    venue_name text NOT NULL,
    venue_address text,
    total_cost numeric(10,2),
    notes text,
    created_by_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    number_of_courts integer DEFAULT 1 NOT NULL
);


--
-- Name: set_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.set_scores (
    id text NOT NULL,
    set_id text NOT NULL,
    user_id text,
    games_won integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    guest_id text
);


--
-- Name: sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sets (
    id text NOT NULL,
    court_id text NOT NULL,
    set_number integer NOT NULL,
    created_by_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    phone text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    avatar_url text,
    is_admin boolean DEFAULT false NOT NULL,
    reset_token text,
    reset_token_expiry timestamp(3) without time zone,
    last_login timestamp(3) without time zone
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d375d4f8-9696-4ff4-a9c2-089ae91af4cc	389529f6317fa0457ac2e38934f9805e36be174bcab685e1271e47ea34cdf1ae	2025-10-05 14:20:39.702554+00	20251003213436_initial_schema	\N	\N	2025-10-05 14:20:39.595923+00	1
1a163ac5-03d0-4cd1-9e3d-dc1c107f6d57	85fd429f5e068d3ba1b885ac1f55003fad2bb7de9fc54df24dd74083c3237db2	2025-10-05 14:20:39.799695+00	20251004202354_court_refactor	\N	\N	2025-10-05 14:20:39.727364+00	1
6b829486-e230-4919-9513-651450ae37e0	65db5a6c64bca4e1c7f7bc9d1db75f73aef7e6ae6cc2fafb5a3c529559f6afc4	2025-10-05 14:20:39.894631+00	add_avatar_url	\N	\N	2025-10-05 14:20:39.830277+00	1
e8030dd6-cc69-4384-8fc2-e15d8fb1dc1a	477fbb2e78f3349f6ed471dd89966a7f4c605aeaf32fc1dc98354a1c461ec839	2025-10-05 14:20:39.988979+00	add_guest_players	\N	\N	2025-10-05 14:20:39.918712+00	1
24e5ac70-2be6-4d5f-8cd9-5c956ab0b8bc	7f1ed1bba0b0674af730cbc2e368d8ada3b20b758c34e7f83be7f02bc6b6ceb6	2025-10-05 20:24:54.446647+00	20251005195243_add_court_cost	\N	\N	2025-10-05 20:24:54.424626+00	1
d5e3e5fd-c573-40f0-98ad-c13cb33ba2bf	e94b86163d0314311c7033b9e91affba70028d1a31e34c2552c93d70d016e5ed	2025-10-05 22:08:26.407363+00	20251005205814_add_match_tracking	\N	\N	2025-10-05 22:08:26.323403+00	1
1ea94f45-c280-4dcc-ac43-6c51994e7265	1f5d310afcf12dc3ef798007363ee0a09a820b5fe13bb4b870a6c1b7d3768e9c	2025-10-05 22:08:26.429414+00	20251005211228_update_match_sets	\N	\N	2025-10-05 22:08:26.412595+00	1
175a3090-d588-4012-a3ae-43e9a490e1db	5b3f557b71960b3f90c856154ad8adfebf2a40b23c6f8ea00dc29385dfe15e50	2025-10-10 07:14:40.802806+00	20251009135254_add_admin_role	\N	\N	2025-10-10 07:14:40.768422+00	1
9ca62e4a-f3b7-4672-80d0-490c01b88c5b	1f15cafdedf16e50ed8f972d755f7cc2fbbb37881ed9ee032de38a8bf4ef8bc1	2025-10-15 10:53:29.885518+00	20251015103918_convert_matches_to_sets	\N	\N	2025-10-15 10:53:29.797547+00	1
198b09ea-8ba6-4d2f-8103-c26b7db4f27e	ae839bb5007ee480a00b939517546a620e6cc586f1368c84593a0b689c4589ac	2025-10-19 19:14:57.508055+00	20251019190851_add_password_reset_tokens	\N	\N	2025-10-19 19:14:57.484294+00	1
1f6fdb23-d4a7-4acb-8755-bf03b4f64413	c96a2304e9abaa7f8dba2c73acbf0cbcb09582cffaa1f2c2b361b6a006404691	2025-10-22 08:06:40.08814+00	20251022080046_support_guest_players_in_sets	\N	\N	2025-10-22 08:06:39.970983+00	1
9364c1dc-41af-48ff-b63b-58383aa397fe	62e91a1eae5378c0abe552b6b2c2d59f29c9313dc810f7110b777c0568351023	2025-11-12 16:24:12.932259+00	20251112000000_add_guest_status	\N	\N	2025-11-12 16:24:12.875536+00	1
794ad13f-1a7f-499e-bc0a-078495827769	8bf6d5622f6cc7ebd2603105bc61b3631923e17c3754b78148c698707af81cc1	2025-12-10 14:00:16.248429+00	20250101000000_add_last_login	\N	\N	2025-12-10 14:00:16.221005+00	1
\.


--
-- Data for Name: courts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courts (id, session_id, court_number, start_time, duration, max_players, created_at, cost) FROM stdin;
ecf533ee-1997-4f27-9fdc-88c64b8a3018	14959251-38e2-4c7c-ac06-aa3bea0c9dec	4	20:30	90	4	2025-10-05 15:18:36.693	\N
571577de-0e6d-4d0d-a933-f7f62ef4ed3e	14959251-38e2-4c7c-ac06-aa3bea0c9dec	8	20:30	90	4	2025-10-05 15:18:36.693	\N
51fd4e9e-2760-4218-8dfd-a7080f52f840	1cec1296-cf58-447c-a49c-300781d51072	4	20:30	90	4	2025-10-06 07:29:45.121	64.26
f9578c39-e7d5-4370-abb9-ddc8ae44ff86	1cec1296-cf58-447c-a49c-300781d51072	6	21:00	60	4	2025-10-06 07:29:45.121	42.84
6eac9a45-172b-45f9-9b2a-2781e859294b	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	1	21:00	60	4	2025-10-08 09:09:16.472	36.08
9985977b-5a34-45a5-9bce-f3dd4303caa5	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	5	21:00	60	4	2025-10-08 09:09:16.472	36.08
0d3a97d4-fcf1-4306-a214-c855ceeef801	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	4	20:30	90	4	2025-10-08 09:19:49.59	64.26
5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	4	21:00	60	4	2025-10-28 21:23:21.543	\N
7987e5b5-b985-4389-b8b2-c39d78e1881c	29d183fe-e8b8-4b69-8138-6d7d7b345941	7	21:00	60	4	2025-10-28 21:29:54.49	43.00
9ad5fd5d-df15-4bf6-8495-0fcfe532758b	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	4	21:00	60	4	2025-11-04 21:46:59.841	42.84
c196ab8d-e232-44d8-9026-4d5a6b105178	42348645-b11f-4556-9673-00c31ce3c995	1	21:00	60	4	2025-11-04 21:52:19.939	43.68
e07ea12e-4b45-424b-b2e0-9a68619f673a	9a967a86-1151-42e5-8e07-9836b280df87	3	20:00	90	4	2025-11-04 22:02:09.792	64.26
47d2663c-08a8-41cb-947f-67b4ad7dabf0	87bb81c5-7186-4722-b9ec-97ee5314e7a2	7	21:00	60	4	2025-11-04 22:08:45.484	\N
4726c7df-114f-4b7d-a720-f4adc8e8b724	68bf262b-5e6d-4824-b332-5b766ad01e75	8	20:30	60	4	2025-11-17 15:40:22.939	46.92
68f59789-6d6c-4285-bf9a-bd8c2e9227c0	68bf262b-5e6d-4824-b332-5b766ad01e75	6	20:30	60	4	2025-11-17 15:40:22.939	42.84
61473c34-ec41-4223-8288-62cd127d0de7	64ed170a-934b-475c-84a0-3262e1bd8217	4	20:00	60	4	2025-11-17 15:44:30.709	42.84
21b1c4bb-b5e5-4ec7-92ee-8a45a488778e	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	7	20:30	90	4	2025-12-01 18:04:12.249	65.00
d9918bfa-6dd4-466d-8cf3-07ffb828b9b8	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	2	21:30	90	4	2025-12-08 15:51:50.955	70.38
6dc57124-8d02-421b-823e-163d282ddc6b	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	4	20:30	90	4	2025-12-10 08:49:36.905	64.26
d28b7a8b-d2ca-47c8-b161-9652fa7ccf11	ba0ad90d-95be-4797-b089-f80b77f34566	6	20:30	90	4	2025-12-10 08:52:16.687	64.26
\.


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guests (id, court_id, name, added_by_id, created_at, session_id, status, updated_at) FROM stdin;
eb1bf217-5177-489f-9baf-0f736b02fa74	571577de-0e6d-4d0d-a933-f7f62ef4ed3e	LO!!!	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-06 16:45:27.725	14959251-38e2-4c7c-ac06-aa3bea0c9dec	yes	2025-11-12 16:24:12.883
b89f32a9-8e3b-4eb8-826f-ba65b58a4db3	f9578c39-e7d5-4370-abb9-ddc8ae44ff86	Lo -Boemboem- Sutherland	06eba835-af09-4574-bbb0-f8386004e7e8	2025-10-13 16:56:39.044	1cec1296-cf58-447c-a49c-300781d51072	yes	2025-11-12 16:24:12.883
d63bf9c4-3b1d-4c64-a8f8-fc5ef9d88e13	f9578c39-e7d5-4370-abb9-ddc8ae44ff86	Maurice	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-14 16:21:44.282	1cec1296-cf58-447c-a49c-300781d51072	yes	2025-11-12 16:24:12.883
ce8173b0-d664-4eb3-b5a5-5c2522b1c77a	9985977b-5a34-45a5-9bce-f3dd4303caa5	Janne	06eba835-af09-4574-bbb0-f8386004e7e8	2025-10-19 19:13:53.99	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	yes	2025-11-12 16:24:12.883
7b956225-c1c2-4ed8-8753-ca2f41d8cb13	9985977b-5a34-45a5-9bce-f3dd4303caa5	Raf	21e97772-af53-41dd-b1e3-6b6ae40462fa	2025-10-19 19:14:07.251	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	yes	2025-11-12 16:24:12.883
96fd4af0-44f8-4ff5-848c-0731d0ac1790	6eac9a45-172b-45f9-9b2a-2781e859294b	Lodie	06eba835-af09-4574-bbb0-f8386004e7e8	2025-10-21 13:31:40.27	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	yes	2025-11-12 16:24:12.883
c844c5b3-875a-424d-b27f-21abe887cc0a	0d3a97d4-fcf1-4306-a214-c855ceeef801	Maurice	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-22 12:07:54.987	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	yes	2025-11-12 16:24:12.883
7e51117d-6f0a-41c9-9fcb-b9487267abc5	\N	Lo	06eba835-af09-4574-bbb0-f8386004e7e8	2025-11-17 15:31:36.664	42348645-b11f-4556-9673-00c31ce3c995	maybe	2025-11-17 15:31:36.664
34521f5b-d952-4165-bf14-afd4ab1e95c9	\N	Lo	06eba835-af09-4574-bbb0-f8386004e7e8	2025-11-18 19:36:31.013	87bb81c5-7186-4722-b9ec-97ee5314e7a2	maybe	2025-11-18 19:36:31.013
cefd67b1-883c-4de2-b5ba-9521cf317584	\N	Lo	06eba835-af09-4574-bbb0-f8386004e7e8	2025-11-22 16:11:16.929	64ed170a-934b-475c-84a0-3262e1bd8217	maybe	2025-11-22 16:11:16.929
b03ac800-663f-432c-8887-c81257acad8a	\N	Julian	06eba835-af09-4574-bbb0-f8386004e7e8	2025-12-03 08:45:26.601	64ed170a-934b-475c-84a0-3262e1bd8217	maybe	2025-12-03 08:45:26.601
9f09051d-d6c3-4dd0-9b49-ebf198992f61	61473c34-ec41-4223-8288-62cd127d0de7	Gui	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-12-08 20:19:56.806	64ed170a-934b-475c-84a0-3262e1bd8217	yes	2025-12-08 20:19:56.806
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, type, title, message, session_id, read, created_at) FROM stdin;
ab9707f3-ef3c-4ef2-8c4d-c99a45c26695	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-07 12:30:49.652
2b8f9e47-dd17-403d-a7b2-d67a32c8e1a6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-07 12:36:07.87
4ac884d5-7c72-4cd9-8ed0-891694514c2d	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	f	2025-10-28 21:23:21.686
295b39b3-8c53-4a6d-8418-5c47bf31ad8b	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	f	2025-10-08 09:09:16.865
01307825-9631-4a61-868b-98d74a0c84c3	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	f	2025-10-28 21:23:21.701
a510e426-63d7-4d33-b78a-80e90d455a0d	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-08 15:51:51.128
d3c9a360-6cf9-4d76-9621-e36e58948cde	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	f	2025-10-08 09:19:49.631
b52fb595-9c8f-4702-ae8b-dde82b993e29	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	f	2025-10-28 21:23:21.701
ca93ab1e-02a1-4f5f-b1f8-36685085e781	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	f	2025-10-08 09:19:49.632
70a027da-7fae-46bd-8018-0139c2fa478b	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	f	2025-10-08 09:19:49.631
9e8aa857-e347-442a-a2b2-060e4f3d42b3	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-08 15:51:51.128
38b287f5-e831-466c-9e65-97a091ac6ed7	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	f	2025-10-28 21:29:54.542
fd186b5e-08d2-40dc-bb82-227945c40a3b	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-08 15:51:51.128
a815bb50-e845-4f2f-a51c-f4a26ce3aa51	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	f	2025-10-28 21:29:54.542
8fd32664-6772-4993-a577-e607b1feb42b	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-28 21:29:54.542
b279f904-3b7e-46cc-b3d6-c1b97d836dfb	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-08 09:09:16.866
d5cffc17-0b77-402c-9cc5-ab8c6ea2384a	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-28 21:23:21.686
6c80f5a4-da65-4a1b-87df-80da4d04aaad	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	alexandre can't make it	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-28 20:22:42.274
74f8e75d-3a89-48fb-b621-40d12e3ba70e	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 15:51:51.127
5334364a-7011-4a0f-beef-bb210533dc2b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Jasper Beex is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-07 20:45:58.083
66ff1ed4-b986-4df7-b397-81fe89fd1b1a	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-08 09:38:53.613
c9a98886-5014-4a7e-b543-f8fe3839513c	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-08 09:19:49.631
81c1caa4-50c0-48b9-9fe3-41943e02d2d0	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	f	2025-12-10 08:49:37.229
37c63eda-77de-4f09-8c24-d2caf0d98d08	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	f	2025-12-10 08:49:37.229
18538c7d-6527-450a-9455-e662175cd3a9	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	t	2025-12-10 08:49:37.228
6ab54f15-9b8d-4aba-805d-5f0e18020e28	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	t	2025-12-10 08:49:37.227
b9625169-182e-4ca2-ba75-87d4fe48fe61	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Olle Dommerholt can't make it	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-09 15:10:27.654
8fb1d969-93f6-46b9-baa9-68b44263d04a	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-02 20:48:03.37
7657e3c7-42bc-4e63-a126-db7ad2664861	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-08 09:09:16.865
087685a5-262b-4877-ab81-fc46a0a270e7	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-08 09:19:49.631
9d350100-5f5d-48d0-9569-88a4105052f7	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-06 07:33:24.538
59a85bba-061c-4873-ac20-c00db919af64	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-06 07:38:16.199
bbf9849d-f319-44c7-8545-e36c1ed12852	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	f	2025-10-28 21:23:21.686
9fbc8154-3605-44ab-b5b4-a14d581b7410	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	f	2025-10-28 21:23:21.701
215969bd-8abe-47de-932c-08a4f2b0e800	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	f	2025-10-28 21:23:21.701
b8ff647d-b10a-4337-ba44-364653befd35	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	f	2025-10-28 21:29:54.543
9b0bcb9d-8522-4023-9ba8-cfac69e7a085	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	f	2025-10-28 21:29:54.542
5dca38cc-0fca-44b6-9ca0-0cbf07b0998d	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/14/2025	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-06 07:29:45.322
ef632365-1597-4d03-9b14-5769fcec081e	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	f	2025-10-08 09:09:16.865
d8f3c656-dfe7-439f-85e7-cd834ae2b4f0	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	f	2025-10-08 09:09:16.866
8b3b203f-2375-4598-9160-85bfa2f54a64	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	f	2025-10-08 09:09:16.865
0eebd912-b169-48a1-820a-fa7402ad4b74	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	f	2025-10-28 21:29:54.543
7a153385-bf9e-4917-93ab-d84ebef72f70	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	f	2025-10-08 09:19:49.631
871d0e98-ebc3-48e5-9673-2f280244ca79	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	f	2025-10-08 09:19:49.631
564b1033-9e4d-40dc-9f18-444c0b22c798	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/14/2025	1cec1296-cf58-447c-a49c-300781d51072	f	2025-10-06 07:29:45.322
1f5d45b6-9da8-4670-add1-713a2721345b	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	f	2025-11-04 21:46:59.981
8633f841-7e8c-4f54-8948-07d97ee0475c	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	f	2025-11-04 21:52:19.97
16b122eb-2f14-4b25-9d3c-18fce10b1cd6	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-08 15:51:51.128
4ca332a5-f8d4-4004-aad4-dff86d3726ed	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	f	2025-11-04 21:52:19.972
d73e3d18-44dd-4720-bd9f-73c7288fbd30	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-08 15:51:51.128
02983b1b-45b0-4e92-be17-38f1c2d49632	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	f	2025-11-04 21:52:19.971
ca78e8d0-0dc1-4b2b-a6b3-fff4bf01eb59	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/14/2025	1cec1296-cf58-447c-a49c-300781d51072	f	2025-10-06 07:29:45.322
39d2de8b-fdd6-4daf-8279-722df9c476e1	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-02 20:48:03.563
9d92b09f-8550-4d7f-96cd-a0182d72dcda	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	f	2025-11-04 22:02:09.846
469c7a8d-7919-454b-bfc6-0bedb644d7af	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	✅ RSVP Update	alexandre is coming	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:53:17.09
993d797a-6b89-4ad4-a0c3-75355ea9edaf	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-28 21:48:27.684
06f5b8fd-9dd8-4f02-8a19-a43da3b66f85	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-28 21:48:27.889
76492011-9e65-4b9f-92fd-16d9cc06c2cd	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-28 21:49:17.867
14e2d8be-ee7e-492e-907b-8e420b0bf500	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/14/2025	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-06 07:29:45.322
4f3e52e5-ea71-46ce-93a8-c0233952edd0	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-13 14:37:34.771
b8dda7a6-969c-4a2f-855f-9395a690932f	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-04 21:52:57.967
94057eff-dadf-4e8b-b51c-2145409d4558	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	f	2025-10-28 21:29:54.545
4f3ecf76-6a84-475c-853c-42c7acb0286d	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-08 15:51:51.128
a6475ff1-f1fd-4268-8e7b-268ed53068c1	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	f	2025-10-08 09:09:16.866
0738d269-1ab9-44d2-a9b2-4de5f10f254e	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	f	2025-12-10 08:49:37.228
e887f914-f2f6-4e54-a180-11c0c20190d7	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	f	2025-12-10 08:49:37.229
682a81a8-2d34-4ab3-a78b-8d03267e9ade	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Emiel is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:10:13.376
6b3f58cd-b8c8-4604-9f19-9f4bf0fabb54	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/28/2025	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-08 09:19:49.631
81611744-e74e-4ded-80e1-43e2ff142070	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:02:09.846
156233c5-9577-42f3-96c4-1104c731272f	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 10:57:47.183
e3611e14-9795-4336-8bff-017cb145d5c1	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at The Paddelers NL - Amsterdam West on 10/21/2025	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-08 09:09:16.866
75d0cfbd-e4a0-4bb7-9f4e-44901596d6cf	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	🤔 RSVP Update	Mark might come	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-10 20:04:45.897
ba46dc4c-18ee-4739-8c79-f1034e441fde	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	f	2025-11-17 15:40:23.111
aa7227cc-5c26-4ab0-bd5e-53824648e88e	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	f	2025-11-17 15:40:23.112
fcd0fc64-8b1a-4fe0-9ec4-f56b51f9a5d2	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	f	2025-11-17 15:40:23.111
19bf4f50-1189-4c9f-b18f-efbca3e37900	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	f	2025-11-17 15:40:23.111
4769b35a-2100-48b0-8e65-c26642fc0683	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	f	2025-11-17 15:40:23.112
5e0ae2ff-0e48-4f90-9146-9f65af74c7e7	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	f	2025-11-17 15:40:23.112
5e21b31a-855c-413d-a0c5-bb8bc7e9cc21	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	f	2025-11-17 15:44:30.743
93fb96c5-859d-467c-b9af-c001774a8038	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	f	2025-11-17 15:44:30.743
726b0465-640b-4ff8-af6b-c825edf45dff	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	f	2025-11-17 15:44:30.743
b5a0577f-a339-4633-8ad2-6a0ce9ef95cc	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	f	2025-11-17 15:44:30.743
0a3e93d4-67b6-4b62-84c8-b6a68d9de9dd	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	f	2025-11-17 15:44:30.743
1c815e75-0cdc-4dbd-8159-7015650e75a8	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	f	2025-11-17 15:44:30.743
97414ea2-a2b2-446f-bfc9-e3d9f57e9593	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-17 15:40:23.111
1980fdac-10bc-4892-85e4-3e7879e72219	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-17 15:44:30.743
22f2796f-fd5a-4c4b-b8bd-18f84688157b	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Mark is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:34.396
5e7c176d-8821-46dd-bad6-37925e2b5a8a	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Mark is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:38.743
b23fd2cc-ab24-42a4-8d76-76f19a18054b	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	❌ RSVP Update	Merino Padellino can't make it	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-20 21:56:53.029
a5116ac1-b6ac-4aa2-9af8-3df059846774	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Mark is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-20 21:56:56.885
81b73b89-822f-425e-bd89-cc92eb58d91b	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Mark is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-20 21:56:57.084
a6b389d8-c7fc-4de0-b79a-9d304f8eecb4	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-28 21:49:29.07
09ac39b9-5e11-4a21-8316-469017f9e4a6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:52:19.97
68a44894-f88b-473a-8df8-486ab8d7330b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	🤔 RSVP Update	Mark might come	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-10 20:04:24.767
c82ad125-1d89-44f5-842a-c82f7f3896b0	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Olle Dommerholt can't make it	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-18 18:28:08.914
a2f0551e-50a4-4524-ac89-640fc988d93b	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	f	2025-12-10 08:49:37.229
4f9cde96-fc1f-4113-bd78-5285deed647d	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	f	2025-12-10 08:52:16.725
85ebbf4f-b98e-4996-9015-2161624a5d11	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	f	2025-12-10 08:52:16.725
066c9828-db56-457c-9d42-13f26fd0c74b	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	f	2025-12-10 08:52:16.725
fb457d5b-b044-4f9a-9436-39e3ba7f55d2	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Olle Dommerholt is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-05 02:40:58.611
01fc8503-46bd-4d07-9dfc-57c1fba53007	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 10:28:40.139
7abeab9a-16d6-4671-8c2f-0a55a6162bc1	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 10:28:40.629
baa210e0-c7ff-4026-ac09-c79bd14f89cc	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	🤔 RSVP Update	Mark might come	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 10:33:12.869
3699b7f6-27b0-4871-bc55-75a887e60e34	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-02 20:49:43.599
f032cde2-2e18-4e5f-b046-a310642a80c0	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-02 20:49:43.777
ae9e3561-1bf9-4a0e-8826-e172807b552b	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/4/2025	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-28 21:23:21.701
39f30a59-bae0-46bd-8325-5677d49bf987	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	f	2025-11-04 21:46:59.98
bb8f7da3-961d-4794-bc89-aff46075df1d	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	f	2025-11-04 21:46:59.981
52b0af03-81fc-407b-a02a-a3fc48977f38	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	f	2025-11-04 21:46:59.981
25fb8d12-fa02-495d-8045-e8ee7b26115f	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	f	2025-11-04 22:02:09.848
0aa3ba60-2603-4e54-96c2-edaf61e7ca07	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	f	2025-11-04 22:02:09.847
6ee30deb-359f-434b-8cba-52d26301a2a8	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:08:45.51
28b0e3bd-6298-4b97-9dd3-73d6e3944c22	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:08:45.51
5601e27b-9302-4f82-ad6e-d663c7cd166c	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:08:45.509
43f6655f-1d11-4b80-85ba-9953a9b131e3	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Remco B is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:09:26.869
c1b5e720-553d-40d2-ba59-4ec07fa9953e	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Remco B is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:09:27.055
196b3d11-bc91-44da-9e6e-47edbb4b39bd	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	🤔 RSVP Update	Merino Padellino might come	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:09:37.216
0dca02f2-5528-4ca5-accd-a108317c6f3f	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Merino Padellino is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:09:38.059
0f5e08e2-8446-45f5-8336-bfcc9ea7e0b1	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Merino Padellino is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:09:38.249
176a2a5a-6baf-49cd-b839-1c5f189e90d3	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	🤔 RSVP Update	Emiel might come	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:10:11.06
568ac7d1-188d-4031-b423-15a9d512ee25	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	rsvp_update	✅ RSVP Update	Emiel is coming	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:10:13.185
21196fca-5a0b-4e21-bc3b-fbe2ae742981	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-04 21:46:59.98
b7a757d2-a2b8-46de-a1d9-530c3d74b0bc	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-29 09:35:57.009
f920e1bc-2e9f-4dbc-88db-1323bb024889	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-29 09:35:57.188
51a62310-3eef-4da6-86e4-503c2530f50d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-08 12:20:37.228
088aa1a8-40bc-4567-84f6-ab2283749f02	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-08 12:20:37.341
5ce2250f-2c45-48b0-954e-54f9926bf426	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-08 12:21:14.303
175f560f-2cc6-4239-93e0-9b26b1ecdc49	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-29 09:36:14.188
1cd10dd1-f798-42c2-a35f-1e0c65c39ff5	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	f	2025-11-04 21:46:59.981
82a1cbb5-71c1-4937-a292-ee514b43dcfc	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	f	2025-11-04 21:52:19.972
cd276693-8972-4ebb-9ed2-18b7f8a69cba	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Jasper Beex is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 20:04:16.091
01a51d42-bab2-40a2-8285-6e10c8f21348	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	f	2025-11-04 21:52:19.972
67efc715-091a-49de-bbe7-a8a15b2141ec	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Jeroen de Raaf is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 15:26:13.78
0aab7b0a-53ec-4053-9c40-36ffd8971070	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	Merino Padellino might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 15:29:36.46
d31c2e2e-6399-45c4-aa59-600f0f672ef1	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 18:53:01.024
488b7e10-2455-4ed3-bc18-c2b22c74be95	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 18:55:50.589
d20dd6df-352c-4340-af03-62d7c2cb8f3b	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:06.725
8b1a1032-094c-42e9-9b14-edf9e234efa4	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:07.814
6975311a-1e12-41db-bfa8-f3e2e7e2cce5	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:08.435
e07d4767-7d54-439c-afab-a83a92d9cc07	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:09.015
a4f7d294-be54-4413-88cb-4ae974ca6b5e	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:10.174
29743858-0408-4622-a00b-c23abae7f2c5	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:10.739
fcb6a04d-2d66-4437-a78d-22bded250649	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	alexandre might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:12.325
b957da9e-e70d-4182-b43d-66db6a6e3cfc	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	❌ RSVP Update	alexandre can't make it	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:18.937
395d3a57-2e79-4ac5-a2a8-f3915b83a9fa	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	alexandre might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:19.769
f378230d-c5a2-4fe2-981c-9ce03be42b29	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	alexandre might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:22.115
ca58cd0c-34a4-4b4f-8646-3ebefff229a4	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	❌ RSVP Update	alexandre can't make it	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:22.887
f197dcfb-d21c-4878-86ff-8c8983a9a596	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	alexandre might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:24.047
18c88222-126b-4232-b7f4-a515ace7fc00	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	❌ RSVP Update	alexandre can't make it	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:07:24.958
ec84e096-5d39-41c4-9e21-aa02972f0df9	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:07.672
ce0309fa-7a40-4ac1-ac38-1d0d0a13fea2	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:10.438
91c545a1-38b5-4130-8aa8-9d0f6550f1a2	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:11.706
48598a61-cb89-412c-84a4-c983a868c777	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	alexandre might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:12.456
b8ca8621-219f-4b2d-8df9-ab38ea29cfbd	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	❌ RSVP Update	alexandre can't make it	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:15.66
1841e412-30dc-4383-898c-414a4fbe66f5	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:21.279
65558620-51f6-49df-9671-9b00191818af	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:08:22.112
082d3f54-5be8-43e2-adce-cfae8dd86e8c	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:09:57.221
35198a8e-4a8f-4a86-a2bf-2fbeff9b95af	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	alexandre is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-05 19:09:59.989
a55b6ba9-a1d9-471d-aedb-1c2b8ed351ba	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Remco B is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 07:24:43.543
031f7545-d64c-4e8c-86ea-d634ee4edb52	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 10/14/2025	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-06 07:29:45.322
8fc675da-e18c-4348-a8bb-4b712e5bb92b	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Olle Dommerholt is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 08:58:33.78
b9df8de2-7931-4502-8be0-b2d7a44faf25	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Mark is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:41.282
8ce51df1-0e12-4566-8c1c-fd01ceaf78f5	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	Mark might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:47.645
75faf226-71e7-45a1-aaf3-f40911a3ffcd	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	❌ RSVP Update	Mark can't make it	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:50.141
476c7e89-458b-4712-9851-35bf13dfd43b	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	🤔 RSVP Update	Mark might come	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:51.384
2d7da618-f7b0-4e8a-a98b-7e6ece4e40d1	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-27 13:07:57.585
34b695bb-dcf0-4ca1-8a33-c52e72e827d0	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Mark is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:04:58.469
7554b0cf-dbf8-450c-bc87-770d181e1a2c	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Mark is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:08:56.241
a3ea6243-b6a2-4e60-b04e-8f84651d8479	564ddabd-b372-4b60-b4bd-d62004157701	rsvp_update	✅ RSVP Update	Mark is coming	14959251-38e2-4c7c-ac06-aa3bea0c9dec	t	2025-10-06 12:08:57.902
376b315b-2dc0-4593-9c54-308cbac2e8ec	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	f	2025-11-04 21:46:59.981
93daaf21-6710-4b18-9bd3-c557ca382e49	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	f	2025-11-04 21:52:19.971
84fc5ab0-efb1-493e-a4e2-328c057865b6	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	f	2025-11-04 22:02:09.846
d968e1f5-db60-463f-b81e-e24f27d7d631	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	f	2025-11-04 22:02:09.846
2f707fba-a1ea-4c86-af00-8262fac20989	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	f	2025-11-04 22:02:09.847
35ea7a94-2e51-47d3-9575-17bab3982488	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/30/2025	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	f	2025-12-10 08:49:37.228
d1584c22-2836-436d-95d3-301594c5b127	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	f	2025-12-10 08:52:16.725
5312a959-a1e3-4edd-b12a-d153c18b1112	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	f	2025-12-10 08:52:16.724
30ecaa00-9c2d-4067-810b-062f95dec49a	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	t	2025-12-10 08:52:16.725
a78273cc-5756-4b01-8c6b-5cded3cced3b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-02 20:50:30.937
ea56dff7-845d-4ab7-aaab-b158afc7357e	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 16:20:41.836
0ca5be88-b6cb-4741-8773-c731c7c27005	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 16:20:42.056
bb4c360c-797a-41aa-876f-11b6b11f34d9	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 16:20:43.239
4f4a2cc5-a1b1-4053-832a-04737238632d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 10:57:47.342
963323b3-6da6-4f17-9a0d-a929e4055229	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:08:45.51
16d53eab-102e-4071-9812-f71f3789a815	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	f	2025-11-04 22:08:45.509
20921c9b-37fd-4b12-90c5-9b85422c65b8	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 17:31:27.55
595e16a4-2177-484d-a620-379ec20f3714	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/20/2025	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-04 21:46:59.981
c0f3b80e-dbda-4c84-9536-15d390fc8b6c	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Merino Padellino created a session at Padel NDSM on 11/18/2025	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:52:19.971
0bb5be67-4565-4662-9e31-65de0c9215af	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	t	2025-11-04 22:08:45.509
13b3b024-081b-4162-9a8e-48559e3956d3	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 17:31:27.839
b9a5e860-a0c6-4134-8d57-4b8f23579d43	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 11:33:46.75
19d4788d-0cbb-4dbd-ad7f-3a3be19d8fb5	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	🤔 RSVP Update	Merino Padellino might come	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:06:46.496
2b67c62b-d3f5-4f71-830e-bec48c3fcfcb	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:06:47.553
d3d6fce5-ba21-4ac5-8c51-06a8cf9a8adc	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:06:47.728
72107397-13c0-41d0-9899-cc9a77fd690d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:06:50.446
5558dabe-a317-4ebd-9c9c-9d866a46d3f6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:07:11.526
a0f0e499-86f3-4bff-b69c-fb66052010f9	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:07:11.74
9b51d18c-50c1-4ff7-b804-d01b55ade4ef	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-07 10:05:35.464
14cd31d8-77b0-46fc-acc4-3175a87ea57b	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-01 18:04:12.376
841cd35c-4a06-498b-a76b-e6613f27e090	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	f	2025-12-10 08:52:16.725
d88300ff-a6a1-47a9-abae-b701fb1b9e33	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-01 18:04:12.376
cf8f958d-ec85-49d3-a4be-9ca6a7ec7c9e	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 18:41:05.462
0be1a8fc-0168-4014-a5b4-7ba24a3b5bbf	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 18:41:05.631
4a9605e4-3e3c-4c71-8c69-98574b7fed2d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Emiel can't make it	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 19:28:18.666
678e8972-e268-4578-aed8-345c2b18ebc1	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 11/13/2025	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-28 21:29:54.541
09f0b8fd-613c-43b1-a1ba-f80bd1903492	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	✅ RSVP Update	alexandre is coming	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:53:17.331
3fe14f8c-98e0-4a02-a41f-c3a62cf3d46b	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	✅ RSVP Update	Emiel is coming	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:53:24.36
06c165b7-783b-423a-9e14-7ef3aadc02e6	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	✅ RSVP Update	Emiel is coming	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:53:24.538
dfc93161-402a-45ac-b9f1-ad6ff2d6aae9	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/2/2025	9a967a86-1151-42e5-8e07-9836b280df87	t	2025-11-04 22:02:09.846
8758a366-c61d-4d53-a569-e3be8e60ec5a	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/11/2025	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-17 15:44:30.743
acefa41f-abcc-4719-871d-d24c5758d090	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	❌ RSVP Update	Mark can't make it	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-18 14:09:12.758
9f4d8842-a5f7-4587-9c87-f8c56c81c9a2	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	✅ RSVP Update	Remco B is coming	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:53:35.272
0c80e892-950a-4092-bb6e-21aa0dfd8e42	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	✅ RSVP Update	Remco B is coming	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-04 21:53:35.47
eada4de5-6b76-489b-9ea0-94487b41b5ee	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	t	2025-11-04 22:08:45.508
a9afd664-b30f-4041-883b-39666baac745	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	🤔 RSVP Update	Jeroen de Raaf might come	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-09 15:21:10.774
e1839316-879a-4f8e-967a-39dc58dae62e	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	🤔 RSVP Update	Mark might come	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-10 20:03:02.856
355fd0fb-6341-4dc3-9740-cd5a1647ad04	21e97772-af53-41dd-b1e3-6b6ae40462fa	rsvp_update	🤔 RSVP Update	Olle Dommerholt might come	42348645-b11f-4556-9673-00c31ce3c995	t	2025-11-15 14:45:23.144
476a654a-430f-4816-be65-b8858c617170	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/16/2025	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-17 15:40:23.111
9f7d0439-6534-4f90-b8aa-a15167cd918e	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	f	2025-12-01 18:04:12.377
5028e0fd-bad8-409e-966c-48c9b4f187e2	0c4c807f-84a9-4929-a7ec-2277f12fa643	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	f	2025-12-01 18:04:12.377
fea13ddc-24a5-4799-a765-e2ad5386b5fa	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	f	2025-12-01 18:04:12.376
1bbc1118-cd97-4c95-9cc8-d059b441dd51	06eba835-af09-4574-bbb0-f8386004e7e8	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	f	2025-12-01 18:04:12.377
4bd58210-5c38-4183-b4f4-4db53b854e29	51fe3d4a-0662-44f3-ba62-0be516e514ee	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	f	2025-12-01 18:04:12.377
f6dec9d0-7e67-47d3-93cb-00ba28292743	09bbdb4a-c701-4563-81c8-7d78cba701a9	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/23/2025	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	f	2025-12-01 18:04:12.376
6b336596-0ff7-4c7b-8997-7a6c77c08707	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Olle Dommerholt can't make it	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-09 15:10:58.593
b8b796cc-b102-4732-9de8-dae7a70c85c3	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-10 09:50:34.136
49aa9939-bfe3-4260-bb1d-348bdf48052d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-10 09:51:34.531
90a30c0d-e637-4f2e-bc74-c89f5ca4b5fb	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Olle Dommerholt can't make it	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-13 13:46:29.067
561a835e-fde3-4c84-b12c-d99fcea705fa	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	1cec1296-cf58-447c-a49c-300781d51072	t	2025-10-14 16:20:43.279
4ffc5bd0-b4b2-4604-9609-329ebe263511	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-15 08:51:58.47
c46ffb68-1ea3-42a2-bcae-16f5c1575ec1	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-15 08:51:58.832
5eff05b7-fb75-4ae3-9ce8-c20c876225b1	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Jeroen de Raaf can't make it	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-16 12:38:49.634
940497a6-8dfd-4ff1-a7cc-040221c41830	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-19 19:14:00.627
b7bb6053-9f54-4ca6-902a-4f79d224a798	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-19 21:13:14.551
aeddc167-b5ad-4982-9b94-26cee56002be	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-20 11:09:54.812
d0d2a9d1-ba68-44b3-904e-595290bb2645	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Jasper Beex is coming	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	t	2025-10-21 13:27:11.029
7b61b557-c048-4edf-8cfb-2ca4f7d7e173	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	alexandre can't make it	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-21 20:29:57.957
751b99fc-5545-4fbb-9d0e-546adc8a7d92	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-04 21:52:58.131
1937a75c-883d-4604-9cc8-2de169a5db9b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Jeroen de Raaf can't make it	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-24 11:04:21.23
967c6ebb-06ed-495d-978c-b01dbafb79f8	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Olle Dommerholt is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-18 18:29:07.856
7baa19dd-d5be-48be-b615-763280a67c80	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	t	2025-10-27 13:07:57.46
ead36a3e-71b0-4d3a-b120-d5bbebe332af	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-29 09:36:14.351
d8ebaf2d-43c2-497e-a6f3-3ca9dd90c99b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Mark can't make it	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-29 18:29:45.196
9db4a6ec-acb3-4d23-a685-028504d8b004	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-29 18:30:06.532
03bd42b9-ae23-4f39-8881-259c16d5efed	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-10-29 18:30:06.694
122de7e1-0949-4b07-8025-0a916f75c148	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-30 09:18:53.294
ab2db5d4-ead6-4836-8b63-1e8d0642e219	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-30 09:18:53.425
4198046f-439c-47aa-9fb5-54f83a87b205	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Olle Dommerholt can't make it	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	t	2025-10-30 20:53:57.232
7b66af01-3b38-410e-8925-b5865c4306d9	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	session_created	🎾 New Padel Session!	alexandre created a session at Padel Next on 11/25/2025	87bb81c5-7186-4722-b9ec-97ee5314e7a2	t	2025-11-04 22:08:45.509
4c0ae2ae-eeea-4ab0-9b4c-030689caa608	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Olle Dommerholt is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-09 11:34:40.105
76d6678b-0cc4-4c96-afe4-a205a0832313	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Olle Dommerholt is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-09 11:34:40.423
4a01aaa6-7acf-434e-8e7f-3fc6802aac5c	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-11-11 09:45:38.054
56bd9538-d799-4669-8176-01e928ce5e01	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	29d183fe-e8b8-4b69-8138-6d7d7b345941	t	2025-11-11 09:45:38.251
2e5c6b28-3c7e-4493-80e2-bc1599350ece	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-11 17:02:34.499
25e42e7b-993f-42eb-9b9d-d33dc57f3e19	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	t	2025-11-11 17:02:34.757
5561653e-df93-41d8-a4ec-d0a5a46f6068	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-20 21:57:12.587
6f17e4bc-b7c6-4434-935c-e397457be331	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-20 21:57:12.784
b28b4d55-26bc-42a9-b41e-3f83880effb5	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-20 21:58:25.944
37bce83f-114f-47de-a7cf-0003049ca248	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Merino Padellino can't make it	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-20 21:59:29.679
68be9450-1fc0-4f78-adbe-09508225b088	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	🤔 RSVP Update	Emiel might come	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-20 21:59:38.874
e14b2644-37c1-4444-94d2-7254789d05c8	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Emiel is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-20 21:59:54.032
eaf82df1-4fbd-4332-9346-51d1be375f43	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-22 16:09:23.201
2e0a4d23-8998-415a-ac13-921913499622	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-22 16:09:23.41
1e1dd850-f42b-45d0-b4c2-5f7e6d4b1610	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Mark is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-24 09:14:52.327
1e4de652-24e7-44da-9be6-a501982afeae	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-25 15:13:09.879
ad6ded75-ac03-4f80-9a9a-737a987a8131	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	64ed170a-934b-475c-84a0-3262e1bd8217	t	2025-11-25 15:13:10.225
7aebf116-7bbc-4d82-a583-cac830b33b3f	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-25 15:13:34.186
c3ae6be3-88b1-4b80-a108-d00b362313a3	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-25 15:13:37.1
3eb0c9db-a440-4c0b-b18c-d27a8da2212d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	alexandre is coming	68bf262b-5e6d-4824-b332-5b766ad01e75	t	2025-11-25 15:13:41.569
2040899f-2e77-4a0d-ae1d-af19f414f276	06eba835-af09-4574-bbb0-f8386004e7e8	session_updated	📝 Session Updated	Remco B updated the session: date, time, venue	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	f	2025-12-09 09:05:30.494
729be5a7-49df-46d7-b753-d700c2fdb98a	564ddabd-b372-4b60-b4bd-d62004157701	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 12/9/2025	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-08 15:51:51.128
ba73ea70-4f93-439f-b781-f043b673ca7d	564ddabd-b372-4b60-b4bd-d62004157701	session_updated	📝 Session Updated	Remco B updated the session: date, time, venue	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-09 09:05:30.493
61236221-0b85-4ec0-a39c-4fe9cc2e97dd	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_created	🎾 New Padel Session!	Remco B created a session at Padel Next on 1/6/2026	ba0ad90d-95be-4797-b089-f80b77f34566	t	2025-12-10 08:52:16.724
1ffa3e76-1265-48a3-b1b1-2ec96c09c71e	21e97772-af53-41dd-b1e3-6b6ae40462fa	session_updated	📝 Session Updated	Remco B updated the session: date, time, venue	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-09 09:05:30.494
84da1a5c-09ec-4dbc-95de-f14e31fa4943	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	❌ RSVP Update	Emiel can't make it	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 08:40:01.513
85fc3f6f-16b5-4081-94be-520384ad0e8c	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	session_updated	📝 Session Updated	Remco B updated the session: date, time, venue	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	t	2025-12-09 09:05:30.493
7c3f14f9-720e-4342-b648-b0abcdd114e7	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Olle Dommerholt is coming	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	t	2025-12-09 20:59:26.071
9cdc5195-cdf3-45db-af8a-7faf179c17fa	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	ba0ad90d-95be-4797-b089-f80b77f34566	t	2025-12-10 15:23:43.893
6dc56313-c3dd-4d55-8d07-edb976152505	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	rsvp_update	✅ RSVP Update	Merino Padellino is coming	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	t	2025-12-10 15:24:07.594
\.


--
-- Data for Name: rsvps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rsvps (id, session_id, user_id, status, created_at, updated_at, court_id) FROM stdin;
a6cf4f3d-027f-4e2b-b356-16cb343392d6	14959251-38e2-4c7c-ac06-aa3bea0c9dec	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-10-05 15:18:50.917	2025-10-05 15:18:50.917	ecf533ee-1997-4f27-9fdc-88c64b8a3018
2fc23904-81fe-427d-b5fa-0c126ba2209c	14959251-38e2-4c7c-ac06-aa3bea0c9dec	09bbdb4a-c701-4563-81c8-7d78cba701a9	yes	2025-10-05 15:26:13.749	2025-10-05 15:26:13.749	571577de-0e6d-4d0d-a933-f7f62ef4ed3e
750fc4ea-213d-4d64-8962-5df8a682c09c	14959251-38e2-4c7c-ac06-aa3bea0c9dec	21e97772-af53-41dd-b1e3-6b6ae40462fa	maybe	2025-10-05 15:29:36.443	2025-10-05 15:29:36.443	\N
cb9b08b5-d2dd-4d2f-a255-6eaf5f4d8673	1cec1296-cf58-447c-a49c-300781d51072	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-10-06 07:33:24.52	2025-10-06 07:33:24.52	51fd4e9e-2760-4218-8dfd-a7080f52f840
8145ca1b-3003-4903-b403-bda23f62faf7	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	no	2025-11-04 21:47:22.491	2025-11-11 09:05:50.88	\N
a2dd7656-d6d5-420a-8113-ef947e9d6252	1cec1296-cf58-447c-a49c-300781d51072	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-10-06 07:38:16.166	2025-10-06 07:38:16.166	51fd4e9e-2760-4218-8dfd-a7080f52f840
15399ae1-5ae2-43f2-8954-1e16347ba75d	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-10-28 21:48:27.656	2025-10-28 21:48:27.872	0d3a97d4-fcf1-4306-a214-c855ceeef801
3887644c-235f-466a-9389-1d7993419196	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-10-28 21:49:17.852	2025-10-28 21:49:17.852	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0
13d472f9-f369-4be1-8704-df3df40a1ad3	29d183fe-e8b8-4b69-8138-6d7d7b345941	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-10-28 21:49:29.055	2025-10-28 21:49:29.055	7987e5b5-b985-4389-b8b2-c39d78e1881c
ab053752-824e-4e19-9220-00c61bec590e	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-10-29 09:35:56.978	2025-10-29 09:35:57.169	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0
60571aea-3981-4051-b70e-c64fa2a9f943	29d183fe-e8b8-4b69-8138-6d7d7b345941	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-10-29 09:36:14.172	2025-10-29 09:36:14.334	7987e5b5-b985-4389-b8b2-c39d78e1881c
adc850e8-6af3-45f0-863d-b03c950cceed	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-10-28 21:23:34.715	2025-10-29 14:17:34.491	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0
dd00a392-06bc-4adf-9db2-09cc0579c78b	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	06eba835-af09-4574-bbb0-f8386004e7e8	no	2025-10-29 18:29:45.134	2025-10-29 18:29:45.134	\N
2c7535dd-2695-4724-9375-24e14b7a8b24	14959251-38e2-4c7c-ac06-aa3bea0c9dec	0c4c807f-84a9-4929-a7ec-2277f12fa643	yes	2025-10-06 08:58:33.749	2025-10-06 08:58:33.749	ecf533ee-1997-4f27-9fdc-88c64b8a3018
5a4a59c7-da54-4ae9-898f-ac5af3fe1d99	29d183fe-e8b8-4b69-8138-6d7d7b345941	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-10-29 18:30:06.513	2025-10-29 18:30:06.679	7987e5b5-b985-4389-b8b2-c39d78e1881c
1cab861c-f5aa-4217-adf1-459e8b2f9553	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-10-08 12:21:14.277	2025-10-08 12:21:14.277	6eac9a45-172b-45f9-9b2a-2781e859294b
2018626a-2958-413d-a392-6c09d5ae5e53	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-10-30 09:18:53.27	2025-10-30 09:18:53.411	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0
1d849812-8841-410a-a8f9-f8bc7766381a	fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	0c4c807f-84a9-4929-a7ec-2277f12fa643	no	2025-10-30 20:53:57.205	2025-10-30 20:53:57.205	\N
ad516668-279b-4eda-830e-777b29d73d8b	29d183fe-e8b8-4b69-8138-6d7d7b345941	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	no	2025-10-28 21:30:17.456	2025-11-11 09:02:27.888	\N
7b899117-de05-41a3-a958-3e65624660bc	14959251-38e2-4c7c-ac06-aa3bea0c9dec	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-10-05 18:53:00.998	2025-10-05 19:09:59.976	571577de-0e6d-4d0d-a933-f7f62ef4ed3e
c1464228-4001-45e7-b0a4-cbab23cf449f	14959251-38e2-4c7c-ac06-aa3bea0c9dec	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-10-06 07:24:43.519	2025-10-06 07:24:43.519	ecf533ee-1997-4f27-9fdc-88c64b8a3018
d60ae831-9287-4659-8308-296523cf0ba6	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	0c4c807f-84a9-4929-a7ec-2277f12fa643	no	2025-10-09 15:10:27.609	2025-10-09 15:10:27.609	\N
1df6eb11-f98c-4f7f-bfd1-3afb38a722be	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	0c4c807f-84a9-4929-a7ec-2277f12fa643	no	2025-10-09 15:10:58.582	2025-10-09 15:10:58.582	\N
9b387499-902f-400c-8d38-5a518e60c105	14959251-38e2-4c7c-ac06-aa3bea0c9dec	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-10-06 12:04:34.365	2025-10-06 12:08:57.89	ecf533ee-1997-4f27-9fdc-88c64b8a3018
1ffbe537-14e8-4ce3-8736-b0570caecd78	14959251-38e2-4c7c-ac06-aa3bea0c9dec	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	yes	2025-10-06 20:04:16.062	2025-10-06 20:04:16.062	571577de-0e6d-4d0d-a933-f7f62ef4ed3e
e8d2bea6-9a34-4921-bb86-d0830792c60f	1cec1296-cf58-447c-a49c-300781d51072	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-10-07 12:30:49.609	2025-10-10 09:50:34.076	f9578c39-e7d5-4370-abb9-ddc8ae44ff86
333e14e4-7c53-4a5c-bf33-46e6858083db	1cec1296-cf58-447c-a49c-300781d51072	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	yes	2025-10-07 20:45:58.055	2025-10-07 20:45:58.055	f9578c39-e7d5-4370-abb9-ddc8ae44ff86
49f8e578-31f5-483d-bbae-169d140ecc17	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-10-08 09:38:53.585	2025-10-08 09:38:53.585	6eac9a45-172b-45f9-9b2a-2781e859294b
75f88b3d-4f8c-49d3-a035-511799c15baa	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-10-08 10:04:42.995	2025-10-08 10:04:42.995	0d3a97d4-fcf1-4306-a214-c855ceeef801
90b8932d-2054-4597-8650-07948d106b40	1cec1296-cf58-447c-a49c-300781d51072	0c4c807f-84a9-4929-a7ec-2277f12fa643	no	2025-10-13 13:46:29.041	2025-10-13 13:46:29.041	\N
52f93aa4-6b52-4b9c-a200-8ee65883ab8f	1cec1296-cf58-447c-a49c-300781d51072	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-10-06 07:30:40.074	2025-10-14 09:34:31.243	51fd4e9e-2760-4218-8dfd-a7080f52f840
c3d6064e-8d5c-4dcc-a191-69d81f831989	1cec1296-cf58-447c-a49c-300781d51072	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-10-07 12:36:07.851	2025-10-14 16:20:43.24	51fd4e9e-2760-4218-8dfd-a7080f52f840
693bc06f-c3f9-40d9-8553-d60024f536ce	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-10-15 08:51:58.428	2025-10-15 08:51:58.813	0d3a97d4-fcf1-4306-a214-c855ceeef801
c812c7eb-5c20-4a7a-9aca-f9ad6a2a81f8	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	09bbdb4a-c701-4563-81c8-7d78cba701a9	no	2025-10-16 12:38:49.575	2025-10-16 12:38:49.575	\N
64437886-daae-46e5-a545-490ee3fdd260	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	yes	2025-10-21 13:27:10.997	2025-10-21 13:27:10.997	6eac9a45-172b-45f9-9b2a-2781e859294b
a33a4e1d-6388-4f4a-bc41-ec71dd8178ec	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-10-13 14:37:34.737	2025-10-19 21:13:14.508	9985977b-5a34-45a5-9bce-f3dd4303caa5
45913e48-2102-4c93-9021-e4659848e381	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	no	2025-10-08 10:05:14.224	2025-10-20 07:48:49.401	\N
fbe724b6-9bf1-435d-95f6-a5b4395ba16a	f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-10-10 09:51:34.513	2025-10-20 11:09:54.761	9985977b-5a34-45a5-9bce-f3dd4303caa5
7781e6cb-554b-49e8-8283-09659b786254	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	09bbdb4a-c701-4563-81c8-7d78cba701a9	no	2025-10-24 11:04:21.197	2025-10-24 11:04:21.197	\N
08af2735-e911-4f8c-a802-e6e849ec2a33	ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	no	2025-10-08 12:20:37.204	2025-10-28 20:22:42.232	\N
848f27b6-3e3f-45f2-ab23-f7226e9bca59	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-11-04 21:52:57.95	2025-11-04 21:52:58.117	9ad5fd5d-df15-4bf6-8495-0fcfe532758b
20e5adf4-7e8d-4ebb-9e28-79e2f9588477	42348645-b11f-4556-9673-00c31ce3c995	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-11-04 21:53:02.992	2025-11-04 21:53:05.047	c196ab8d-e232-44d8-9026-4d5a6b105178
b9e2a560-f02e-454b-b007-b7e0bf94aff7	42348645-b11f-4556-9673-00c31ce3c995	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-11-04 21:53:17.078	2025-11-04 21:53:17.319	c196ab8d-e232-44d8-9026-4d5a6b105178
145e2707-0b93-4b60-a422-7ee023553b06	42348645-b11f-4556-9673-00c31ce3c995	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-11-04 21:53:24.348	2025-11-04 21:53:24.526	c196ab8d-e232-44d8-9026-4d5a6b105178
a873d888-8877-487d-99b1-81caaf38e0bb	42348645-b11f-4556-9673-00c31ce3c995	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-11-04 21:53:35.259	2025-11-04 21:53:35.457	c196ab8d-e232-44d8-9026-4d5a6b105178
bc461a84-3114-43ef-a8f2-464ad0acce88	9a967a86-1151-42e5-8e07-9836b280df87	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-11-04 22:06:46.474	2025-11-04 22:06:47.714	e07ea12e-4b45-424b-b2e0-9a68619f673a
18f0b348-6838-4c28-bc5e-a9946649c7b7	9a967a86-1151-42e5-8e07-9836b280df87	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-11-04 22:06:50.429	2025-11-04 22:06:50.429	e07ea12e-4b45-424b-b2e0-9a68619f673a
3464271e-d31a-4733-9cda-bcad7875395d	9a967a86-1151-42e5-8e07-9836b280df87	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-11-04 22:06:50.4	2025-11-04 22:06:50.582	e07ea12e-4b45-424b-b2e0-9a68619f673a
9a41509f-6216-4270-a00b-391866b3dfa5	9a967a86-1151-42e5-8e07-9836b280df87	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-11-04 22:07:11.51	2025-11-04 22:07:11.719	e07ea12e-4b45-424b-b2e0-9a68619f673a
876ca8df-9c6b-4180-bdd8-81980aacd42e	87bb81c5-7186-4722-b9ec-97ee5314e7a2	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-11-04 22:09:10.729	2025-11-04 22:09:10.96	47d2663c-08a8-41cb-947f-67b4ad7dabf0
e09c0384-e238-496f-a3fd-423d8b1c7e4a	87bb81c5-7186-4722-b9ec-97ee5314e7a2	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-11-04 22:09:26.854	2025-11-04 22:09:27.039	47d2663c-08a8-41cb-947f-67b4ad7dabf0
02156ee1-848b-49a1-81bb-7c75d162a0a0	87bb81c5-7186-4722-b9ec-97ee5314e7a2	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-11-04 22:10:11.046	2025-11-04 22:10:13.361	47d2663c-08a8-41cb-947f-67b4ad7dabf0
322fcbf7-e279-45cd-9ad4-fef19697e335	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-11-07 10:05:35.435	2025-11-07 10:05:35.435	9ad5fd5d-df15-4bf6-8495-0fcfe532758b
5b231796-2df8-4a94-821e-a48d328a87d5	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	0c4c807f-84a9-4929-a7ec-2277f12fa643	yes	2025-11-09 11:34:40.078	2025-11-09 11:34:40.406	9ad5fd5d-df15-4bf6-8495-0fcfe532758b
0106f761-a3bf-46c1-9b5a-637686fd8b77	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-12-01 18:04:31.653	2025-12-01 18:04:31.818	21b1c4bb-b5e5-4ec7-92ee-8a45a488778e
581dfdf2-f1e6-4783-a1f3-1a1dbad085ed	42348645-b11f-4556-9673-00c31ce3c995	09bbdb4a-c701-4563-81c8-7d78cba701a9	maybe	2025-11-09 15:21:10.745	2025-11-09 15:21:10.745	\N
a7b64f93-67d5-4ad5-ba6d-ac149311463c	29d183fe-e8b8-4b69-8138-6d7d7b345941	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-11-11 09:45:38.027	2025-11-11 09:45:38.234	7987e5b5-b985-4389-b8b2-c39d78e1881c
d8dda229-213f-475b-9299-8e9da36914bf	49c32ebe-f3e4-4b97-bca7-0b7709b437d7	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-11-10 20:04:24.752	2025-11-11 17:02:34.742	9ad5fd5d-df15-4bf6-8495-0fcfe532758b
c807676f-40ce-4f29-9ae1-ed67d9eec378	42348645-b11f-4556-9673-00c31ce3c995	0c4c807f-84a9-4929-a7ec-2277f12fa643	maybe	2025-11-15 14:45:23.114	2025-11-15 14:45:23.114	\N
3b022bce-c832-4e29-a437-4305203e60e6	68bf262b-5e6d-4824-b332-5b766ad01e75	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-11-17 15:41:07.262	2025-11-17 15:41:07.262	4726c7df-114f-4b7d-a720-f4adc8e8b724
6420b0d9-92d8-4c19-a036-6414951d6391	64ed170a-934b-475c-84a0-3262e1bd8217	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-11-17 15:45:07.782	2025-11-17 15:45:14.671	61473c34-ec41-4223-8288-62cd127d0de7
a7e488b1-50b1-48fb-bdb8-b8b4e3a52996	42348645-b11f-4556-9673-00c31ce3c995	06eba835-af09-4574-bbb0-f8386004e7e8	no	2025-11-10 20:03:02.825	2025-11-18 14:09:12.727	\N
a50848c3-6a27-4daf-b304-7b1730e917c8	64ed170a-934b-475c-84a0-3262e1bd8217	0c4c807f-84a9-4929-a7ec-2277f12fa643	no	2025-11-18 18:28:08.883	2025-11-18 18:28:08.883	\N
26dd86d7-1582-47b2-b7a6-3216fcccd8af	68bf262b-5e6d-4824-b332-5b766ad01e75	0c4c807f-84a9-4929-a7ec-2277f12fa643	yes	2025-11-18 18:29:07.84	2025-11-18 18:29:07.84	4726c7df-114f-4b7d-a720-f4adc8e8b724
0abe077d-f0c1-456b-9324-5be7f85fca83	87bb81c5-7186-4722-b9ec-97ee5314e7a2	21e97772-af53-41dd-b1e3-6b6ae40462fa	no	2025-11-04 22:09:37.202	2025-11-20 21:56:53.003	\N
65fea4b3-a5b1-4e0c-a822-62a20c99c570	87bb81c5-7186-4722-b9ec-97ee5314e7a2	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-11-10 20:04:45.882	2025-11-20 21:56:57.07	47d2663c-08a8-41cb-947f-67b4ad7dabf0
ab062abf-9922-4557-8d2d-4bce5b293bda	64ed170a-934b-475c-84a0-3262e1bd8217	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-11-22 16:09:23.171	2025-11-22 16:09:23.393	61473c34-ec41-4223-8288-62cd127d0de7
776863dc-4dd3-4e49-af5e-f42e534cc81c	68bf262b-5e6d-4824-b332-5b766ad01e75	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-11-20 21:58:25.93	2025-11-20 21:58:25.93	4726c7df-114f-4b7d-a720-f4adc8e8b724
6fa8d323-e266-42a4-838f-90ab1afcf1a1	64ed170a-934b-475c-84a0-3262e1bd8217	21e97772-af53-41dd-b1e3-6b6ae40462fa	no	2025-11-20 21:57:12.571	2025-11-20 21:59:29.666	\N
3511144e-525e-47eb-8f38-92847fc1ac2d	68bf262b-5e6d-4824-b332-5b766ad01e75	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-11-20 21:59:38.861	2025-11-20 21:59:54.018	4726c7df-114f-4b7d-a720-f4adc8e8b724
d59a11cf-5463-4899-a69f-fa9e773e5d69	68bf262b-5e6d-4824-b332-5b766ad01e75	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-11-24 09:14:52.303	2025-11-24 09:14:52.303	68f59789-6d6c-4285-bf9a-bd8c2e9227c0
e5bc8f6f-1de3-422d-9d70-6b1de9510853	64ed170a-934b-475c-84a0-3262e1bd8217	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-11-25 15:13:09.851	2025-11-25 15:13:10.206	61473c34-ec41-4223-8288-62cd127d0de7
b157e128-7264-4e82-bbf4-8251ab84381e	68bf262b-5e6d-4824-b332-5b766ad01e75	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-11-25 15:13:34.167	2025-11-25 15:13:41.553	68f59789-6d6c-4285-bf9a-bd8c2e9227c0
9f96a95d-81fa-4ae6-89a6-dd6540d999b8	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-12-02 20:48:03.344	2025-12-02 20:48:03.545	21b1c4bb-b5e5-4ec7-92ee-8a45a488778e
99510587-c545-4a08-9d4b-da51f4301156	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	yes	2025-12-02 20:49:43.58	2025-12-02 20:49:43.764	21b1c4bb-b5e5-4ec7-92ee-8a45a488778e
2adc621f-3246-4b02-8e49-2b454ad7c585	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-12-08 15:52:17.824	2025-12-08 15:52:24.885	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8
7cf710f5-1d4b-4ecd-a5c0-e9bf8d6fcdb1	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	564ddabd-b372-4b60-b4bd-d62004157701	yes	2025-12-08 16:20:41.81	2025-12-08 16:20:43.207	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8
afb21e8a-ecd9-4c67-8bbe-9455505bfaee	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	0c4c807f-84a9-4929-a7ec-2277f12fa643	yes	2025-12-05 02:40:58.589	2025-12-09 20:59:26.043	21b1c4bb-b5e5-4ec7-92ee-8a45a488778e
006c90cc-266e-4afd-a701-2ad4842a8011	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	564ddabd-b372-4b60-b4bd-d62004157701	no	2025-12-02 20:50:30.924	2025-12-09 19:28:17.978	\N
0d78098d-d16d-4dfb-93f7-6c54b3689a25	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-12-08 17:31:27.383	2025-12-08 17:31:27.814	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8
f2c072a7-0d04-4f55-9c8e-e44f51d0d2d8	9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-12-08 18:41:05.425	2025-12-08 18:41:05.611	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8
23060ff2-b7e6-4021-b8a6-47e5f9df5097	a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	06eba835-af09-4574-bbb0-f8386004e7e8	yes	2025-12-09 10:28:40.113	2025-12-09 11:33:46.731	\N
0d43465c-fce1-45b9-9e55-178b4a7aef30	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-12-10 08:50:00.901	2025-12-10 08:50:01.027	6dc57124-8d02-421b-823e-163d282ddc6b
af0727f7-0197-4248-8ecb-01957140d7fe	ba0ad90d-95be-4797-b089-f80b77f34566	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	yes	2025-12-10 08:52:37.749	2025-12-10 08:52:37.889	d28b7a8b-d2ca-47c8-b161-9652fa7ccf11
07ce1756-c2de-4d00-b6c0-565a6f03892a	ba0ad90d-95be-4797-b089-f80b77f34566	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-12-10 15:23:43.867	2025-12-10 15:23:43.867	d28b7a8b-d2ca-47c8-b161-9652fa7ccf11
363315bd-3c38-4cb2-ad57-029c2c67bd27	674a2357-e1cb-4c3f-aa11-4f867ade0bd7	21e97772-af53-41dd-b1e3-6b6ae40462fa	yes	2025-12-10 15:24:07.577	2025-12-10 15:24:07.577	6dc57124-8d02-421b-823e-163d282ddc6b
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, date, "time", venue_name, venue_address, total_cost, notes, created_by_id, created_at, updated_at, number_of_courts) FROM stdin;
14959251-38e2-4c7c-ac06-aa3bea0c9dec	2025-10-07 00:00:00	20:30	Padel Next	\N	\N	\N	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-05 15:18:36.693	2025-10-05 15:18:36.693	2
1cec1296-cf58-447c-a49c-300781d51072	2025-10-14 00:00:00	20:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-06 07:29:45.121	2025-10-06 07:29:45.121	2
f4c15fcb-230f-4b09-89ed-64d77cf7d6a5	2025-10-21 00:00:00	21:00	The Paddelers NL - Amsterdam West	\N	\N	Condensatorweg 48, 1014 AX, Amsterdam (achter Sloterdijk)	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-08 09:09:16.472	2025-10-08 09:09:16.472	2
ca6b516e-a5f1-4d0a-98ce-86a8056cf8d5	2025-10-28 00:00:00	20:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-08 09:19:49.59	2025-10-08 09:19:49.59	1
fbbb1d8e-9c99-4f78-a49a-9bd61c04ad2c	2025-11-04 00:00:00	21:00	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-28 21:23:21.543	2025-10-28 21:23:21.543	1
29d183fe-e8b8-4b69-8138-6d7d7b345941	2025-11-13 00:00:00	21:00	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-10-28 21:29:54.49	2025-10-28 21:29:54.49	1
49c32ebe-f3e4-4b97-bca7-0b7709b437d7	2025-11-20 00:00:00	21:00	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-11-04 21:46:59.841	2025-11-04 21:46:59.841	1
42348645-b11f-4556-9673-00c31ce3c995	2025-11-18 00:00:00	21:00	Padel NDSM	\N	\N	Lekker in Noord 🧭	21e97772-af53-41dd-b1e3-6b6ae40462fa	2025-11-04 21:52:19.939	2025-11-04 21:52:19.939	1
9a967a86-1151-42e5-8e07-9836b280df87	2025-12-02 00:00:00	20:00	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-11-04 22:02:09.792	2025-11-04 22:02:09.792	1
87bb81c5-7186-4722-b9ec-97ee5314e7a2	2025-11-25 00:00:00	21:00	Padel Next	\N	\N	\N	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	2025-11-04 22:08:45.484	2025-11-04 22:08:45.484	1
68bf262b-5e6d-4824-b332-5b766ad01e75	2025-12-16 00:00:00	20:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-11-17 15:40:22.939	2025-11-17 15:40:22.939	2
64ed170a-934b-475c-84a0-3262e1bd8217	2025-12-11 00:00:00	20:00	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-11-17 15:44:30.709	2025-11-17 15:44:30.709	1
a7a12738-a02f-4ee6-bb5f-c8075a5fc87c	2025-12-23 00:00:00	20:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-12-01 18:04:12.249	2025-12-01 18:04:12.249	1
9a6cedb0-79c2-4a24-9b08-c8affc7c4a5a	2025-12-09 00:00:00	21:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-12-08 15:51:50.955	2025-12-09 09:05:30.471	1
674a2357-e1cb-4c3f-aa11-4f867ade0bd7	2025-12-30 00:00:00	20:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-12-10 08:49:36.905	2025-12-10 08:49:36.905	1
ba0ad90d-95be-4797-b089-f80b77f34566	2026-01-06 00:00:00	20:30	Padel Next	\N	\N	\N	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2025-12-10 08:52:16.687	2025-12-10 08:52:16.687	1
\.


--
-- Data for Name: set_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.set_scores (id, set_id, user_id, games_won, created_at, guest_id) FROM stdin;
43b940e7-3883-4e0c-9212-5ba4e018e2ca	80220346-4b31-49c2-8bc4-840d4960d4b6	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-10-15 21:17:38.714	\N
ad79d321-c6cb-4762-a59e-b0f1677aaf0a	80220346-4b31-49c2-8bc4-840d4960d4b6	21e97772-af53-41dd-b1e3-6b6ae40462fa	1	2025-10-15 21:17:38.714	\N
2aff2fae-5e3e-4ead-8de2-e55af880f229	80220346-4b31-49c2-8bc4-840d4960d4b6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-15 21:17:38.714	\N
40eab50a-8a4a-4709-9969-161c2052e89c	80220346-4b31-49c2-8bc4-840d4960d4b6	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	1	2025-10-15 21:17:38.714	\N
0a2f4b68-c15a-402a-b83c-3f83263111b9	5f1f74c5-e1a0-4a90-858b-fb837f060c30	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-10-15 21:17:38.837	\N
28c3654a-45ad-4416-bcf2-b438c49712d9	5f1f74c5-e1a0-4a90-858b-fb837f060c30	21e97772-af53-41dd-b1e3-6b6ae40462fa	2	2025-10-15 21:17:38.837	\N
61578e74-2e5e-4268-a401-368801a9944b	5f1f74c5-e1a0-4a90-858b-fb837f060c30	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-15 21:17:38.837	\N
8eeec77f-fd21-4675-a02f-5b43cf6b619f	5f1f74c5-e1a0-4a90-858b-fb837f060c30	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	2	2025-10-15 21:17:38.837	\N
643f9a35-81e6-45b7-b130-06d87975aac2	81280d1e-2afd-469b-ad6d-ee3b95bc4a18	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-10-15 21:17:38.905	\N
686d724f-78ee-41d8-aec1-22afb3bf1a64	81280d1e-2afd-469b-ad6d-ee3b95bc4a18	21e97772-af53-41dd-b1e3-6b6ae40462fa	3	2025-10-15 21:17:38.905	\N
58ea21e1-ff30-4cd8-9f1a-edb55a40d255	81280d1e-2afd-469b-ad6d-ee3b95bc4a18	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-15 21:17:38.905	\N
aa5e1fde-6edd-4ee2-a0a8-41b5d4f8a6b2	81280d1e-2afd-469b-ad6d-ee3b95bc4a18	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	3	2025-10-15 21:17:38.905	\N
bab95554-5b18-4115-bfcd-cb8f8813e2f2	9b05ea6a-b3dd-48a2-bd62-c93a494aa0d6	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-10-15 21:17:38.978	\N
59b567c5-3670-44af-b125-390a4d62e9ee	9b05ea6a-b3dd-48a2-bd62-c93a494aa0d6	21e97772-af53-41dd-b1e3-6b6ae40462fa	5	2025-10-15 21:17:38.978	\N
6d7356f3-9ddc-48b1-a210-83934c608883	9b05ea6a-b3dd-48a2-bd62-c93a494aa0d6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	5	2025-10-15 21:17:38.978	\N
a6a062f8-1e24-4365-97c6-503e39e9452e	9b05ea6a-b3dd-48a2-bd62-c93a494aa0d6	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	3	2025-10-15 21:17:38.978	\N
a995efe7-6827-4d92-a650-7a36b07bfc5f	d096e6f6-f641-430e-b9ff-8bc70bd8214c	564ddabd-b372-4b60-b4bd-d62004157701	5	2025-10-15 21:19:49.763	\N
c903d515-8c21-4f83-b76e-a2e155bb2905	d096e6f6-f641-430e-b9ff-8bc70bd8214c	0c4c807f-84a9-4929-a7ec-2277f12fa643	5	2025-10-15 21:19:49.763	\N
72de7443-ee42-4949-9ecd-18bee014c8f6	d096e6f6-f641-430e-b9ff-8bc70bd8214c	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	7	2025-10-15 21:19:49.763	\N
4c2a97cf-55d7-47ed-8d03-2ebfc192ece0	d096e6f6-f641-430e-b9ff-8bc70bd8214c	06eba835-af09-4574-bbb0-f8386004e7e8	7	2025-10-15 21:19:49.763	\N
9e527456-a994-4705-8e02-6a2869949d33	e2feac9f-9dae-4712-963a-2e37a839694b	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-10-15 21:19:49.84	\N
c820bfd8-17ed-48b3-bd06-6a391671db5d	e2feac9f-9dae-4712-963a-2e37a839694b	0c4c807f-84a9-4929-a7ec-2277f12fa643	6	2025-10-15 21:19:49.84	\N
3c3bdfc2-4de3-48d4-8f3a-8387c933469c	e2feac9f-9dae-4712-963a-2e37a839694b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	2	2025-10-15 21:19:49.84	\N
01241a51-76bf-4cfb-b0ca-f0b1e3d03844	e2feac9f-9dae-4712-963a-2e37a839694b	06eba835-af09-4574-bbb0-f8386004e7e8	2	2025-10-15 21:19:49.84	\N
86a63a83-ec6b-42a7-b821-d7e6783e627f	cacd106d-497c-4952-917f-7e7c63aab67d	564ddabd-b372-4b60-b4bd-d62004157701	2	2025-10-15 21:19:49.908	\N
b81428ff-9c0e-4879-907c-7bef882af07d	cacd106d-497c-4952-917f-7e7c63aab67d	0c4c807f-84a9-4929-a7ec-2277f12fa643	2	2025-10-15 21:19:49.908	\N
8fcd7525-b8c5-40ad-af85-e85af1cf7603	cacd106d-497c-4952-917f-7e7c63aab67d	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-15 21:19:49.908	\N
da6bb74f-cdc9-4e44-b699-dbb86f4061ce	cacd106d-497c-4952-917f-7e7c63aab67d	06eba835-af09-4574-bbb0-f8386004e7e8	6	2025-10-15 21:19:49.908	\N
badab2fc-c6c8-4128-8ad6-401a5b2fbad6	af21c37a-5ea2-4090-b50b-3bd54796b725	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	6	2025-10-22 09:09:21.017	\N
1fb91143-3c35-4c68-a9ed-118563a66b6a	af21c37a-5ea2-4090-b50b-3bd54796b725	564ddabd-b372-4b60-b4bd-d62004157701	1	2025-10-22 09:09:21.017	\N
bb989f81-f155-4568-b313-6697ed4d3aa2	af21c37a-5ea2-4090-b50b-3bd54796b725	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	1	2025-10-22 09:09:21.017	\N
b44b205e-991e-49e0-bd51-9da122d5b7e9	af21c37a-5ea2-4090-b50b-3bd54796b725	\N	6	2025-10-22 09:09:21.017	96fd4af0-44f8-4ff5-848c-0731d0ac1790
78de73ce-3b54-4e4f-84fd-24a12ff6540e	20193bc2-fbdb-4900-94bc-78b58fc9ed46	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	6	2025-10-22 09:09:21.133	\N
03ac1d12-31d0-4a60-8d11-a971ac39d3dd	20193bc2-fbdb-4900-94bc-78b58fc9ed46	564ddabd-b372-4b60-b4bd-d62004157701	1	2025-10-22 09:09:21.133	\N
f3f5d1b1-3b28-4075-be24-5b92ac78dc3e	20193bc2-fbdb-4900-94bc-78b58fc9ed46	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	1	2025-10-22 09:09:21.133	\N
e6e51744-daa6-4c6e-9d95-155d56365f5d	20193bc2-fbdb-4900-94bc-78b58fc9ed46	\N	6	2025-10-22 09:09:21.133	96fd4af0-44f8-4ff5-848c-0731d0ac1790
58e0ca75-76fc-4c76-bc54-6b1dd799d4fe	c9e0d3fb-aadb-4d31-8da6-f133170bda4a	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	4	2025-10-22 09:09:21.223	\N
98c6e320-422a-45aa-bfbb-77933c4e6019	c9e0d3fb-aadb-4d31-8da6-f133170bda4a	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-10-22 09:09:21.223	\N
bfd88c9b-05e2-4d16-9543-197b11e0545d	c9e0d3fb-aadb-4d31-8da6-f133170bda4a	99e5175c-f55d-423a-90b4-7d7bbc87e6e5	3	2025-10-22 09:09:21.223	\N
4d418294-9713-4835-833a-a4fa12fb43a8	c9e0d3fb-aadb-4d31-8da6-f133170bda4a	\N	4	2025-10-22 09:09:21.223	96fd4af0-44f8-4ff5-848c-0731d0ac1790
ff847f0a-780a-474b-bc80-23014b0492bd	d260053c-eaeb-4999-b762-41cf37fb6d3b	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-10-22 10:32:55.236	\N
c3a417bb-c22d-455a-9d6a-0aa4c46f82c5	d260053c-eaeb-4999-b762-41cf37fb6d3b	06eba835-af09-4574-bbb0-f8386004e7e8	5	2025-10-22 10:32:55.236	\N
083a75bc-f190-47af-b70a-642578f123d8	d260053c-eaeb-4999-b762-41cf37fb6d3b	\N	6	2025-10-22 10:32:55.236	ce8173b0-d664-4eb3-b5a5-5c2522b1c77a
c51b426a-3698-4ec8-8805-f835d5f925d9	d260053c-eaeb-4999-b762-41cf37fb6d3b	\N	5	2025-10-22 10:32:55.236	7b956225-c1c2-4ed8-8753-ca2f41d8cb13
a41a646a-3cab-44f1-aa8f-a1bbfbf70878	9eadab1a-aa33-483f-8f7c-82a07d8a3274	21e97772-af53-41dd-b1e3-6b6ae40462fa	4	2025-10-22 10:32:55.985	\N
9f74be19-f962-4e36-848c-c689a1fafbfa	9eadab1a-aa33-483f-8f7c-82a07d8a3274	06eba835-af09-4574-bbb0-f8386004e7e8	6	2025-10-22 10:32:55.985	\N
ef9b2d9d-f50f-4fc2-ad9d-fa34232da1e9	9eadab1a-aa33-483f-8f7c-82a07d8a3274	\N	6	2025-10-22 10:32:55.985	ce8173b0-d664-4eb3-b5a5-5c2522b1c77a
3c4b34d9-85c9-474f-955b-04643e0c42e1	9eadab1a-aa33-483f-8f7c-82a07d8a3274	\N	4	2025-10-22 10:32:55.985	7b956225-c1c2-4ed8-8753-ca2f41d8cb13
d91d9bad-7b4b-4f2a-8364-931943406e1d	b1565024-5d04-470c-90b3-b34cfd5f9b75	564ddabd-b372-4b60-b4bd-d62004157701	0	2025-10-28 21:52:11.118	\N
f1b71f6f-a109-4ed2-953e-c4c056286385	b1565024-5d04-470c-90b3-b34cfd5f9b75	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-28 21:52:11.118	\N
2f18876e-8d1e-4233-bf87-64a3f7b84337	b1565024-5d04-470c-90b3-b34cfd5f9b75	06eba835-af09-4574-bbb0-f8386004e7e8	0	2025-10-28 21:52:11.118	\N
88ccb535-3d56-4ae3-8446-f05440730dbc	b1565024-5d04-470c-90b3-b34cfd5f9b75	\N	6	2025-10-28 21:52:11.118	c844c5b3-875a-424d-b27f-21abe887cc0a
6ea0d8b7-071b-4f4c-97bc-ee9a53d96b81	c148e22a-e934-436d-818c-e98631cf8c93	564ddabd-b372-4b60-b4bd-d62004157701	0	2025-10-28 21:52:11.24	\N
f4190001-8268-48bf-9c59-2dd8b46cb492	c148e22a-e934-436d-818c-e98631cf8c93	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-28 21:52:11.24	\N
1853e41a-d3e4-4a0e-9934-87da086abe01	c148e22a-e934-436d-818c-e98631cf8c93	06eba835-af09-4574-bbb0-f8386004e7e8	0	2025-10-28 21:52:11.24	\N
1c55e868-c83e-4042-9dd9-06083d4b720e	c148e22a-e934-436d-818c-e98631cf8c93	\N	6	2025-10-28 21:52:11.24	c844c5b3-875a-424d-b27f-21abe887cc0a
ea24dbaa-f05e-4ce0-ad87-25fb857f021e	05ce608d-0ab5-498d-86a0-b7a7c82424d9	564ddabd-b372-4b60-b4bd-d62004157701	1	2025-10-28 21:52:11.384	\N
b12180d0-5bfd-416c-8af7-44bb2843974d	05ce608d-0ab5-498d-86a0-b7a7c82424d9	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-10-28 21:52:11.384	\N
e05fed5b-dc38-4084-a3b8-fced59041141	05ce608d-0ab5-498d-86a0-b7a7c82424d9	06eba835-af09-4574-bbb0-f8386004e7e8	1	2025-10-28 21:52:11.384	\N
ebf77275-ba73-4a00-8ddd-0c32f52e50bb	05ce608d-0ab5-498d-86a0-b7a7c82424d9	\N	6	2025-10-28 21:52:11.384	c844c5b3-875a-424d-b27f-21abe887cc0a
11f372c8-789a-4eaf-8600-190c0121df8a	8b84d159-c141-4989-8405-3fff72b8be2a	564ddabd-b372-4b60-b4bd-d62004157701	7	2025-10-28 21:52:11.491	\N
474a58ea-6148-44d8-bc07-875a1b7b5b4d	8b84d159-c141-4989-8405-3fff72b8be2a	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	5	2025-10-28 21:52:11.491	\N
c4e7affd-9067-45b5-b0b8-758839aed361	8b84d159-c141-4989-8405-3fff72b8be2a	06eba835-af09-4574-bbb0-f8386004e7e8	5	2025-10-28 21:52:11.491	\N
6b1fcc08-2aee-404a-b5b0-1392736f2ade	8b84d159-c141-4989-8405-3fff72b8be2a	\N	7	2025-10-28 21:52:11.491	c844c5b3-875a-424d-b27f-21abe887cc0a
6d3dee5e-6def-4bc0-b40a-ad47c10b06f0	d77d5c9c-a3fc-45f7-8710-5f2c04b8669b	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-10-28 21:52:11.592	\N
adc9103b-115e-4d43-bedc-b92b55c5df8e	d77d5c9c-a3fc-45f7-8710-5f2c04b8669b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	1	2025-10-28 21:52:11.592	\N
385fb73d-9cc4-4227-9a48-15f8a5a95471	d77d5c9c-a3fc-45f7-8710-5f2c04b8669b	06eba835-af09-4574-bbb0-f8386004e7e8	1	2025-10-28 21:52:11.592	\N
0a3d9f2b-be0d-4152-9981-7271b8cabc59	d77d5c9c-a3fc-45f7-8710-5f2c04b8669b	\N	3	2025-10-28 21:52:11.592	c844c5b3-875a-424d-b27f-21abe887cc0a
cdbfd9e6-0078-4ffd-b034-1c9284a361bd	e5adcc9a-0a3f-4bb5-94ee-7d4847d54ecf	564ddabd-b372-4b60-b4bd-d62004157701	4	2025-11-04 21:57:42.102	\N
d2d2cdb9-64d0-4805-9f36-cd9c5454408d	e5adcc9a-0a3f-4bb5-94ee-7d4847d54ecf	21e97772-af53-41dd-b1e3-6b6ae40462fa	4	2025-11-04 21:57:42.102	\N
1ec2b7ab-38bd-4837-a6d2-7d24255fcb7d	e5adcc9a-0a3f-4bb5-94ee-7d4847d54ecf	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-11-04 21:57:42.102	\N
9e0b643a-da17-4f89-82a2-877cb4b3a701	e5adcc9a-0a3f-4bb5-94ee-7d4847d54ecf	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	6	2025-11-04 21:57:42.102	\N
bdf20b5c-2be2-4232-aa4d-3871354748c6	4bd5c711-eda4-424e-97f8-80fe1e26a9c6	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-11-04 21:57:42.252	\N
c5ce8bb4-a698-456b-9e88-dea81d32cbeb	4bd5c711-eda4-424e-97f8-80fe1e26a9c6	21e97772-af53-41dd-b1e3-6b6ae40462fa	3	2025-11-04 21:57:42.252	\N
e185e387-0df2-4ef9-97ca-e3654ee378d6	4bd5c711-eda4-424e-97f8-80fe1e26a9c6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-11-04 21:57:42.252	\N
d2a4df45-95ad-4403-8d83-b66fd89a39a7	4bd5c711-eda4-424e-97f8-80fe1e26a9c6	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	6	2025-11-04 21:57:42.252	\N
706fca38-4b4e-41b6-8d10-cff24129c933	58211ba9-3f2f-4fe4-8087-2f880aee5f3f	564ddabd-b372-4b60-b4bd-d62004157701	7	2025-11-04 21:57:42.64	\N
c948a9c3-40b1-4d60-9e45-994bb40b5a30	58211ba9-3f2f-4fe4-8087-2f880aee5f3f	21e97772-af53-41dd-b1e3-6b6ae40462fa	7	2025-11-04 21:57:42.64	\N
2ae37fa5-9932-43c1-95da-46ce34c42bdf	58211ba9-3f2f-4fe4-8087-2f880aee5f3f	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	5	2025-11-04 21:57:42.64	\N
45e5b2a4-f77d-4621-85f8-2399a668fd24	58211ba9-3f2f-4fe4-8087-2f880aee5f3f	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	5	2025-11-04 21:57:42.64	\N
bc2eb0a2-5089-43e0-8476-2ee3260ee078	1116e8c4-e529-4a69-8751-15531b818d1e	564ddabd-b372-4b60-b4bd-d62004157701	5	2025-11-13 21:35:58.864	\N
99ff9b20-7803-49f7-9a22-dee61df3a2b2	1116e8c4-e529-4a69-8751-15531b818d1e	21e97772-af53-41dd-b1e3-6b6ae40462fa	5	2025-11-13 21:35:58.864	\N
f482a0dc-b8d9-4021-b994-33e9a5b27477	1116e8c4-e529-4a69-8751-15531b818d1e	06eba835-af09-4574-bbb0-f8386004e7e8	7	2025-11-13 21:35:58.864	\N
0cacd289-eec2-4be5-9f00-f1c9323af992	1116e8c4-e529-4a69-8751-15531b818d1e	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	7	2025-11-13 21:35:58.864	\N
47f63be6-e347-4af3-9cf3-77a627f0f4b3	a0c07466-6cf3-4eca-ac9e-9d251f7c69fa	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-11-13 21:35:59.085	\N
0da9c762-c6ff-4071-bfed-b7169d3cf5b9	a0c07466-6cf3-4eca-ac9e-9d251f7c69fa	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-11-13 21:35:59.085	\N
18d8408d-d4c1-4be3-ac93-ac2268d60654	a0c07466-6cf3-4eca-ac9e-9d251f7c69fa	06eba835-af09-4574-bbb0-f8386004e7e8	3	2025-11-13 21:35:59.085	\N
4bff1624-e72d-4ff1-9cd8-06d23c038524	a0c07466-6cf3-4eca-ac9e-9d251f7c69fa	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	3	2025-11-13 21:35:59.085	\N
104fca3b-0c75-4073-ae9a-172b6c40a05b	138e4084-5186-4bf5-a0a1-133a819199cf	564ddabd-b372-4b60-b4bd-d62004157701	5	2025-11-13 21:35:59.24	\N
60d9d1f8-3220-4fd2-98e1-518c0ea6c370	138e4084-5186-4bf5-a0a1-133a819199cf	21e97772-af53-41dd-b1e3-6b6ae40462fa	5	2025-11-13 21:35:59.24	\N
29acafc5-c3e0-4565-9457-3adee7a0e5bb	138e4084-5186-4bf5-a0a1-133a819199cf	06eba835-af09-4574-bbb0-f8386004e7e8	6	2025-11-13 21:35:59.24	\N
bd1f2f7b-8086-48a4-9f33-b0501dd83371	138e4084-5186-4bf5-a0a1-133a819199cf	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	6	2025-11-13 21:35:59.24	\N
ce15c0aa-2534-4066-acb1-88bf800a94f4	fdcde8f7-1148-4cbb-8b06-83479a5fb1c4	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-11-18 21:05:26.694	\N
f9af2f98-9fd4-4862-8d58-a7eed8bd3aa8	fdcde8f7-1148-4cbb-8b06-83479a5fb1c4	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	1	2025-11-18 21:05:26.694	\N
f48cea56-33d3-436f-9418-b0a1908c283b	fdcde8f7-1148-4cbb-8b06-83479a5fb1c4	564ddabd-b372-4b60-b4bd-d62004157701	1	2025-11-18 21:05:26.694	\N
7a4afcf3-b3a9-4758-ab49-28c39fc7cb0c	fdcde8f7-1148-4cbb-8b06-83479a5fb1c4	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-11-18 21:05:26.694	\N
47e37bc7-8db6-4f52-ba01-5240bf5b9eea	7cacf05d-9fbe-438b-8618-3c2fefc55420	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-11-18 21:05:26.868	\N
6ca5318c-bbfd-4bf8-abc1-353ad5eafbe2	7cacf05d-9fbe-438b-8618-3c2fefc55420	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	2	2025-11-18 21:05:26.868	\N
28fe278a-66c3-4e0f-89b7-aad9fbb161db	7cacf05d-9fbe-438b-8618-3c2fefc55420	564ddabd-b372-4b60-b4bd-d62004157701	2	2025-11-18 21:05:26.868	\N
df17019b-75af-4264-add7-971c2c27a0ed	7cacf05d-9fbe-438b-8618-3c2fefc55420	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-11-18 21:05:26.868	\N
350577c2-25ee-4633-9a59-8fc41ebb5988	eb336a1d-1407-40ea-91cf-0fe29d2ff752	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-11-18 21:05:26.969	\N
e8ccd0d4-6a4e-4223-8432-7137ec3c9237	eb336a1d-1407-40ea-91cf-0fe29d2ff752	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	3	2025-11-18 21:05:26.969	\N
b0b2bb7c-dba9-4195-9b6e-e76b79226f50	eb336a1d-1407-40ea-91cf-0fe29d2ff752	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-11-18 21:05:26.969	\N
2ffed9f0-1641-4552-a5d2-d24fdda796e5	eb336a1d-1407-40ea-91cf-0fe29d2ff752	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-11-18 21:05:26.969	\N
c2aa70c7-5eba-4bf0-b0e5-f6a6790720fb	e244f4e5-b712-4e5d-a6b2-4146b9721347	21e97772-af53-41dd-b1e3-6b6ae40462fa	4	2025-11-20 21:27:26.799	\N
1b47d298-dedf-4eb4-a105-1336906625dd	e244f4e5-b712-4e5d-a6b2-4146b9721347	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-11-20 21:27:26.799	\N
aafc7a31-49bd-4fe8-bc3b-be85c8c860ea	e244f4e5-b712-4e5d-a6b2-4146b9721347	0c4c807f-84a9-4929-a7ec-2277f12fa643	6	2025-11-20 21:27:26.799	\N
1b432dbc-1865-4a8d-8ea2-54cb14349d66	e244f4e5-b712-4e5d-a6b2-4146b9721347	06eba835-af09-4574-bbb0-f8386004e7e8	4	2025-11-20 21:27:26.799	\N
9af2d213-2e4a-4443-8517-365d39d83100	79ab54d6-47ae-4768-8765-a16cadcda80f	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-11-20 21:27:26.916	\N
dd901a55-7acf-4715-9295-17e1fb07b7b6	79ab54d6-47ae-4768-8765-a16cadcda80f	564ddabd-b372-4b60-b4bd-d62004157701	4	2025-11-20 21:27:26.916	\N
0fd2acc0-36e2-4289-ab41-a8bb344e6d63	79ab54d6-47ae-4768-8765-a16cadcda80f	0c4c807f-84a9-4929-a7ec-2277f12fa643	4	2025-11-20 21:27:26.916	\N
ed0444a4-d48d-4304-933c-2ca660db906b	79ab54d6-47ae-4768-8765-a16cadcda80f	06eba835-af09-4574-bbb0-f8386004e7e8	6	2025-11-20 21:27:26.916	\N
dbec5081-9ed1-4704-abcc-a3a400ca6911	9a78ea59-aea9-4c7d-81ef-a1c0a41c071d	21e97772-af53-41dd-b1e3-6b6ae40462fa	4	2025-11-20 21:27:27.064	\N
b1055172-99aa-4c98-89f5-a35998afaec1	9a78ea59-aea9-4c7d-81ef-a1c0a41c071d	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-11-20 21:27:27.064	\N
621d50f5-a256-41b7-84e5-24eaecb8dbff	9a78ea59-aea9-4c7d-81ef-a1c0a41c071d	0c4c807f-84a9-4929-a7ec-2277f12fa643	6	2025-11-20 21:27:27.064	\N
f6891647-83e6-4c2a-b998-590d01188dee	9a78ea59-aea9-4c7d-81ef-a1c0a41c071d	06eba835-af09-4574-bbb0-f8386004e7e8	4	2025-11-20 21:27:27.064	\N
42021c08-7c0f-44e5-9409-1290b34a64e1	1f1477dc-5416-49bd-aa94-fd210cb0ec36	21e97772-af53-41dd-b1e3-6b6ae40462fa	0	2025-11-20 21:27:27.221	\N
17a0676f-22e5-465c-97d3-68bd8cd5f900	1f1477dc-5416-49bd-aa94-fd210cb0ec36	564ddabd-b372-4b60-b4bd-d62004157701	6	2025-11-20 21:27:27.221	\N
b2951628-f1e4-4f64-9b8f-bc0a6500764d	1f1477dc-5416-49bd-aa94-fd210cb0ec36	0c4c807f-84a9-4929-a7ec-2277f12fa643	6	2025-11-20 21:27:27.221	\N
736b9518-878b-484b-9279-bc44d570b4bb	1f1477dc-5416-49bd-aa94-fd210cb0ec36	06eba835-af09-4574-bbb0-f8386004e7e8	0	2025-11-20 21:27:27.221	\N
79fc37e1-ed71-4db8-a6a0-ee16d7878b53	b8daf3b2-466d-46d8-91c8-c3459e8f210c	21e97772-af53-41dd-b1e3-6b6ae40462fa	7	2025-12-02 20:40:33.693	\N
99e82fe6-3dc4-4cd4-baf2-fbba7585125f	b8daf3b2-466d-46d8-91c8-c3459e8f210c	564ddabd-b372-4b60-b4bd-d62004157701	7	2025-12-02 20:40:33.693	\N
cd3ea0f4-c3e9-4972-89e1-cbe0e4aa5e44	b8daf3b2-466d-46d8-91c8-c3459e8f210c	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	5	2025-12-02 20:40:33.693	\N
e30ea4db-0df6-4e6c-a549-a244aa1a53d0	b8daf3b2-466d-46d8-91c8-c3459e8f210c	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	5	2025-12-02 20:40:33.693	\N
cd0fcab0-abc5-424c-ad7a-82ddf3a5b6ed	c2ae6f61-a1fe-4423-ad78-6efcf141aca0	21e97772-af53-41dd-b1e3-6b6ae40462fa	5	2025-12-02 20:40:33.826	\N
1a3ded7a-0eac-43d2-85b3-28854724162d	c2ae6f61-a1fe-4423-ad78-6efcf141aca0	564ddabd-b372-4b60-b4bd-d62004157701	5	2025-12-02 20:40:33.826	\N
66c694aa-3395-49d6-9cd1-07954d958ca7	c2ae6f61-a1fe-4423-ad78-6efcf141aca0	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	7	2025-12-02 20:40:33.826	\N
de8dbc28-a5d6-4f1a-b954-86734fece605	c2ae6f61-a1fe-4423-ad78-6efcf141aca0	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	7	2025-12-02 20:40:33.826	\N
2eadb9d1-1c97-439a-b8f5-c58342f31e25	0bd32cf9-949d-4188-9f2e-8873c7561cb6	21e97772-af53-41dd-b1e3-6b6ae40462fa	5	2025-12-02 20:40:33.935	\N
26c2bf32-8b5f-40a3-93cd-adfa78a7d9c2	0bd32cf9-949d-4188-9f2e-8873c7561cb6	564ddabd-b372-4b60-b4bd-d62004157701	5	2025-12-02 20:40:33.935	\N
adccdfbd-6705-4e2b-acc1-ad7d8b07cf35	0bd32cf9-949d-4188-9f2e-8873c7561cb6	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-02 20:40:33.935	\N
c2508896-5aa3-4928-adfb-b83ff345d842	0bd32cf9-949d-4188-9f2e-8873c7561cb6	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	6	2025-12-02 20:40:33.935	\N
4b5fc1a6-2632-4e2f-90de-436cf07debee	cb3784b9-e8e0-4ac7-a7ad-f4a3dad29f4b	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	1	2025-12-02 20:42:23.171	\N
cc468d89-ab10-4dc6-b5d8-adf02997ae98	cb3784b9-e8e0-4ac7-a7ad-f4a3dad29f4b	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-02 20:42:23.171	\N
89b8ace7-a1df-41dc-97ed-2d62a3372dfb	cb3784b9-e8e0-4ac7-a7ad-f4a3dad29f4b	564ddabd-b372-4b60-b4bd-d62004157701	1	2025-12-02 20:42:23.171	\N
51d7f27f-3bc2-42b1-9d93-01aadb084194	cb3784b9-e8e0-4ac7-a7ad-f4a3dad29f4b	06eba835-af09-4574-bbb0-f8386004e7e8	6	2025-12-02 20:42:23.171	\N
9bc22fa0-2419-40ad-86e9-0578de98da4f	78a645bf-54da-45f8-a494-e6cdb4eaa6ad	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	5	2025-12-02 20:42:23.286	\N
7e881356-9c5a-4eec-8eb5-0bdeb500b895	78a645bf-54da-45f8-a494-e6cdb4eaa6ad	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	7	2025-12-02 20:42:23.286	\N
1485f134-43f1-4b70-abf8-fa5a80a5c143	78a645bf-54da-45f8-a494-e6cdb4eaa6ad	564ddabd-b372-4b60-b4bd-d62004157701	5	2025-12-02 20:42:23.286	\N
447b9160-67a5-4d64-aff4-1be5771439b1	78a645bf-54da-45f8-a494-e6cdb4eaa6ad	06eba835-af09-4574-bbb0-f8386004e7e8	7	2025-12-02 20:42:23.286	\N
3cf84abe-8d92-4509-9b19-b195e820d866	08426ee9-c7a9-4464-9a11-50f712baa4b4	d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	2	2025-12-02 20:42:23.403	\N
59beae1b-a1fb-433d-a629-02d27fa4f4cf	08426ee9-c7a9-4464-9a11-50f712baa4b4	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-02 20:42:23.403	\N
cc300d6e-5329-4d90-a66a-2b8881702311	08426ee9-c7a9-4464-9a11-50f712baa4b4	564ddabd-b372-4b60-b4bd-d62004157701	2	2025-12-02 20:42:23.403	\N
b58a948d-017d-46b7-bde6-21750ef00d86	08426ee9-c7a9-4464-9a11-50f712baa4b4	06eba835-af09-4574-bbb0-f8386004e7e8	6	2025-12-02 20:42:23.403	\N
8e0b09b8-f93a-402b-9440-e8daec6b24b0	97e6b855-7082-4dcd-91c6-583db34c6ecf	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-09 22:07:05.28	\N
935c0a5a-1234-4b78-83e9-3373a444e674	97e6b855-7082-4dcd-91c6-583db34c6ecf	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-12-09 22:07:05.28	\N
6a29e8a3-df12-450e-afc5-022c4c635f6e	97e6b855-7082-4dcd-91c6-583db34c6ecf	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-12-09 22:07:05.28	\N
8a717cf5-dc8f-4b6e-8346-b95a82bf037f	97e6b855-7082-4dcd-91c6-583db34c6ecf	06eba835-af09-4574-bbb0-f8386004e7e8	3	2025-12-09 22:07:05.28	\N
3bf42f12-8f48-454c-8ff1-edcf7d1f53d0	8c9fd0b9-9296-4951-b4e3-cf1eee5bb782	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-09 22:07:05.814	\N
9d8fddee-7a21-483f-a143-53f0c2ed51a4	8c9fd0b9-9296-4951-b4e3-cf1eee5bb782	564ddabd-b372-4b60-b4bd-d62004157701	3	2025-12-09 22:07:05.814	\N
385b1da1-f079-4e81-834f-66b1fcb616f2	8c9fd0b9-9296-4951-b4e3-cf1eee5bb782	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-12-09 22:07:05.814	\N
416d0b22-e6ae-449e-81f4-bdb76fb9d553	8c9fd0b9-9296-4951-b4e3-cf1eee5bb782	06eba835-af09-4574-bbb0-f8386004e7e8	3	2025-12-09 22:07:05.814	\N
003daea7-ad5c-4670-865d-d20147edceaf	2396a10c-c7d8-4b06-b27c-43fbc8e4e107	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-09 22:07:05.926	\N
d18b7c3a-a3cf-48bc-829b-029d71642bc6	2396a10c-c7d8-4b06-b27c-43fbc8e4e107	564ddabd-b372-4b60-b4bd-d62004157701	2	2025-12-09 22:07:05.926	\N
8dd3cc66-5731-4a5b-93cb-7835f6dd7e05	2396a10c-c7d8-4b06-b27c-43fbc8e4e107	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-12-09 22:07:05.926	\N
c5edbc82-fc0d-4da6-8c94-b51e5ce7e672	2396a10c-c7d8-4b06-b27c-43fbc8e4e107	06eba835-af09-4574-bbb0-f8386004e7e8	2	2025-12-09 22:07:05.926	\N
0897ab10-c7ad-450c-a65a-ee07fc50dae3	00e0feff-ff69-40c1-9c87-6fba2b272917	2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	6	2025-12-09 22:07:06.045	\N
36711868-a3a5-4441-930a-8852ae2480da	00e0feff-ff69-40c1-9c87-6fba2b272917	564ddabd-b372-4b60-b4bd-d62004157701	4	2025-12-09 22:07:06.045	\N
8e98333d-2358-4d30-836e-246e0cef58a6	00e0feff-ff69-40c1-9c87-6fba2b272917	21e97772-af53-41dd-b1e3-6b6ae40462fa	6	2025-12-09 22:07:06.045	\N
647d0810-86ea-4ccb-9b19-82f707124bfe	00e0feff-ff69-40c1-9c87-6fba2b272917	06eba835-af09-4574-bbb0-f8386004e7e8	4	2025-12-09 22:07:06.045	\N
\.


--
-- Data for Name: sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sets (id, court_id, set_number, created_by_id, created_at, updated_at) FROM stdin;
80220346-4b31-49c2-8bc4-840d4960d4b6	51fd4e9e-2760-4218-8dfd-a7080f52f840	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:17:38.714	2025-10-15 21:17:38.714
5f1f74c5-e1a0-4a90-858b-fb837f060c30	51fd4e9e-2760-4218-8dfd-a7080f52f840	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:17:38.837	2025-10-15 21:17:38.837
81280d1e-2afd-469b-ad6d-ee3b95bc4a18	51fd4e9e-2760-4218-8dfd-a7080f52f840	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:17:38.905	2025-10-15 21:17:38.905
9b05ea6a-b3dd-48a2-bd62-c93a494aa0d6	51fd4e9e-2760-4218-8dfd-a7080f52f840	4	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:17:38.978	2025-10-15 21:17:38.978
d096e6f6-f641-430e-b9ff-8bc70bd8214c	ecf533ee-1997-4f27-9fdc-88c64b8a3018	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:19:49.763	2025-10-15 21:19:49.763
e2feac9f-9dae-4712-963a-2e37a839694b	ecf533ee-1997-4f27-9fdc-88c64b8a3018	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:19:49.84	2025-10-15 21:19:49.84
cacd106d-497c-4952-917f-7e7c63aab67d	ecf533ee-1997-4f27-9fdc-88c64b8a3018	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-15 21:19:49.908	2025-10-15 21:19:49.908
af21c37a-5ea2-4090-b50b-3bd54796b725	6eac9a45-172b-45f9-9b2a-2781e859294b	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-22 09:09:21.017	2025-10-22 09:09:21.017
20193bc2-fbdb-4900-94bc-78b58fc9ed46	6eac9a45-172b-45f9-9b2a-2781e859294b	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-22 09:09:21.133	2025-10-22 09:09:21.133
c9e0d3fb-aadb-4d31-8da6-f133170bda4a	6eac9a45-172b-45f9-9b2a-2781e859294b	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-22 09:09:21.223	2025-10-22 09:09:21.223
d260053c-eaeb-4999-b762-41cf37fb6d3b	9985977b-5a34-45a5-9bce-f3dd4303caa5	1	21e97772-af53-41dd-b1e3-6b6ae40462fa	2025-10-22 10:32:55.236	2025-10-22 10:32:55.236
9eadab1a-aa33-483f-8f7c-82a07d8a3274	9985977b-5a34-45a5-9bce-f3dd4303caa5	2	21e97772-af53-41dd-b1e3-6b6ae40462fa	2025-10-22 10:32:55.985	2025-10-22 10:32:55.985
b1565024-5d04-470c-90b3-b34cfd5f9b75	0d3a97d4-fcf1-4306-a214-c855ceeef801	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-28 21:52:11.118	2025-10-28 21:52:11.118
c148e22a-e934-436d-818c-e98631cf8c93	0d3a97d4-fcf1-4306-a214-c855ceeef801	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-28 21:52:11.24	2025-10-28 21:52:11.24
05ce608d-0ab5-498d-86a0-b7a7c82424d9	0d3a97d4-fcf1-4306-a214-c855ceeef801	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-28 21:52:11.384	2025-10-28 21:52:11.384
8b84d159-c141-4989-8405-3fff72b8be2a	0d3a97d4-fcf1-4306-a214-c855ceeef801	4	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-28 21:52:11.491	2025-10-28 21:52:11.491
d77d5c9c-a3fc-45f7-8710-5f2c04b8669b	0d3a97d4-fcf1-4306-a214-c855ceeef801	5	564ddabd-b372-4b60-b4bd-d62004157701	2025-10-28 21:52:11.592	2025-10-28 21:52:11.592
e5adcc9a-0a3f-4bb5-94ee-7d4847d54ecf	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-04 21:57:42.102	2025-11-04 21:57:42.102
4bd5c711-eda4-424e-97f8-80fe1e26a9c6	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-04 21:57:42.252	2025-11-04 21:57:42.252
58211ba9-3f2f-4fe4-8087-2f880aee5f3f	5f8be2d4-708b-4fa6-a1f9-b90d8b56cfe0	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-04 21:57:42.64	2025-11-04 21:57:42.64
1116e8c4-e529-4a69-8751-15531b818d1e	7987e5b5-b985-4389-b8b2-c39d78e1881c	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-13 21:35:58.864	2025-11-13 21:35:58.864
a0c07466-6cf3-4eca-ac9e-9d251f7c69fa	7987e5b5-b985-4389-b8b2-c39d78e1881c	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-13 21:35:59.085	2025-11-13 21:35:59.085
138e4084-5186-4bf5-a0a1-133a819199cf	7987e5b5-b985-4389-b8b2-c39d78e1881c	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-13 21:35:59.24	2025-11-13 21:35:59.24
fdcde8f7-1148-4cbb-8b06-83479a5fb1c4	c196ab8d-e232-44d8-9026-4d5a6b105178	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-18 21:05:26.694	2025-11-18 21:05:26.694
7cacf05d-9fbe-438b-8618-3c2fefc55420	c196ab8d-e232-44d8-9026-4d5a6b105178	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-18 21:05:26.868	2025-11-18 21:05:26.868
eb336a1d-1407-40ea-91cf-0fe29d2ff752	c196ab8d-e232-44d8-9026-4d5a6b105178	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-18 21:05:26.969	2025-11-18 21:05:26.969
e244f4e5-b712-4e5d-a6b2-4146b9721347	9ad5fd5d-df15-4bf6-8495-0fcfe532758b	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-20 21:27:26.799	2025-11-20 21:27:26.799
79ab54d6-47ae-4768-8765-a16cadcda80f	9ad5fd5d-df15-4bf6-8495-0fcfe532758b	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-20 21:27:26.916	2025-11-20 21:27:26.916
9a78ea59-aea9-4c7d-81ef-a1c0a41c071d	9ad5fd5d-df15-4bf6-8495-0fcfe532758b	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-20 21:27:27.064	2025-11-20 21:27:27.064
1f1477dc-5416-49bd-aa94-fd210cb0ec36	9ad5fd5d-df15-4bf6-8495-0fcfe532758b	4	564ddabd-b372-4b60-b4bd-d62004157701	2025-11-20 21:27:27.221	2025-11-20 21:27:27.221
b8daf3b2-466d-46d8-91c8-c3459e8f210c	e07ea12e-4b45-424b-b2e0-9a68619f673a	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-02 20:40:33.693	2025-12-02 20:40:33.693
c2ae6f61-a1fe-4423-ad78-6efcf141aca0	e07ea12e-4b45-424b-b2e0-9a68619f673a	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-02 20:40:33.826	2025-12-02 20:40:33.826
0bd32cf9-949d-4188-9f2e-8873c7561cb6	e07ea12e-4b45-424b-b2e0-9a68619f673a	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-02 20:40:33.935	2025-12-02 20:40:33.935
cb3784b9-e8e0-4ac7-a7ad-f4a3dad29f4b	47d2663c-08a8-41cb-947f-67b4ad7dabf0	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-02 20:42:23.171	2025-12-02 20:42:23.171
78a645bf-54da-45f8-a494-e6cdb4eaa6ad	47d2663c-08a8-41cb-947f-67b4ad7dabf0	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-02 20:42:23.286	2025-12-02 20:42:23.286
08426ee9-c7a9-4464-9a11-50f712baa4b4	47d2663c-08a8-41cb-947f-67b4ad7dabf0	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-02 20:42:23.403	2025-12-02 20:42:23.403
97e6b855-7082-4dcd-91c6-583db34c6ecf	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8	1	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-09 22:07:05.28	2025-12-09 22:07:05.28
8c9fd0b9-9296-4951-b4e3-cf1eee5bb782	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8	2	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-09 22:07:05.814	2025-12-09 22:07:05.814
2396a10c-c7d8-4b06-b27c-43fbc8e4e107	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8	3	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-09 22:07:05.926	2025-12-09 22:07:05.926
00e0feff-ff69-40c1-9c87-6fba2b272917	d9918bfa-6dd4-466d-8cf3-07ffb828b9b8	4	564ddabd-b372-4b60-b4bd-d62004157701	2025-12-09 22:07:06.045	2025-12-09 22:07:06.045
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, name, phone, created_at, updated_at, avatar_url, is_admin, reset_token, reset_token_expiry, last_login) FROM stdin;
09bbdb4a-c701-4563-81c8-7d78cba701a9	jeroenderaaf@gmail.com	$2a$10$bmkXfsY.Pla7QpEyk11cOukgViNxKbXWtU8nOv4hla54/5/MuJ.FS	Jeroen de Raaf	0624357844	2025-10-05 15:21:11.107	2025-10-05 15:26:59.594	\N	f	\N	\N	\N
2b7a605b-1f89-4b0f-a2f3-03e5f600abd2	remcoboing@gmail.com	$2a$10$xgi37iDY3WlHBL8LLy10WO1tOAPW9Go1Q12HCs78/SMLiScLJBbEO	Remco B	+31654952449	2025-10-06 07:23:52.002	2025-10-08 09:57:57.946	https://res.cloudinary.com/dxo999vvl/image/upload/v1759917476/padel-avatars/pvw8p5xpnntpprmzpbl9.png	f	\N	\N	\N
d3e892a5-d8f7-43a1-9ef1-0c52740e3fa4	alexandre@soufan.nl	$2a$10$4c1H37lJqIzy9Fn4V8yH5.LLffhjZiFouM4R4uLfGsF2dA5QFGqIi	alexandre	\N	2025-10-05 18:51:06.737	2025-10-05 19:08:42.215	https://res.cloudinary.com/dxo999vvl/image/upload/v1759691320/padel-avatars/eqjamtnpfs03nkqb2fkd.png	f	\N	\N	\N
0c4c807f-84a9-4929-a7ec-2277f12fa643	olledommerholt@gmail.com	$2a$10$WupOWHr2vHBeLIZtctCE7eDd0IcbTksg1hfzYBmo8i9b1VqcIjuLm	Olle Dommerholt	\N	2025-10-06 08:57:32.804	2025-10-06 08:57:32.804	\N	f	\N	\N	\N
99e5175c-f55d-423a-90b4-7d7bbc87e6e5	beexjasper@gmail.com	$2a$10$28zc8OYXOtvUb1sp/0SUTOOEKZ1MGc.15qQMcFr/hSy/mpg1x6.0i	Jasper Beex	+31638064489	2025-10-06 20:02:13.643	2025-10-20 12:19:52.203	https://res.cloudinary.com/dxo999vvl/image/upload/v1759781231/padel-avatars/laohhjild5go4mpwk0re.jpg	f	c11fbf57cdb368f0f05113c7d9edcf903bfe8b45bcac3b7629219b53926c7ac1	2025-10-20 06:46:02.525	\N
564ddabd-b372-4b60-b4bd-d62004157701	emiel@emielloonen.nl	$2a$10$iAKctsC0978YQXTirx/I6.hanCovycvS1NOFAt0cqPYn7O2vAzBQ6	Emiel	+31619346936	2025-10-05 15:17:15.216	2025-12-10 14:10:01.73	https://res.cloudinary.com/dxo999vvl/image/upload/v1759682097/padel-avatars/npbanyp0nm1kcvbyxga7.jpg	t	55eda19b4a5a87dcb49b677b0310988fbe6217a7e73d628de66b8cc54917f658	2025-10-20 08:43:19.169	2025-12-10 14:10:01.729
21e97772-af53-41dd-b1e3-6b6ae40462fa	merien@gmail.com	$2a$10$Vf0qVJEzghTT0fH5179XqOLzGScITLyEbBx3Lk6YxsmcV1nXJbdOy	Merino Padellino	0625053707	2025-10-05 15:29:23.213	2025-12-10 21:57:13.232	https://res.cloudinary.com/dxo999vvl/image/upload/v1759914425/padel-avatars/cll6b81thecjexzbgzk0.jpg	f	\N	\N	2025-12-10 21:57:13.231
06eba835-af09-4574-bbb0-f8386004e7e8	alineo@upcmail.nl	$2a$10$jymvJGZ.L.EQFOMQ1eMvPeXAsQlOla/bD/NL.ljyReANYgZQs2g8C	Mark	\N	2025-10-05 20:13:29.714	2025-10-07 12:50:53.007	https://res.cloudinary.com/dxo999vvl/image/upload/v1759841448/padel-avatars/sv11xy10jqogflwdjwnv.png	f	\N	\N	\N
51fe3d4a-0662-44f3-ba62-0be516e514ee	guest@placeholder.local	$2a$10$cV35jBiavb0Fjh7MHWSgNOPsgoOZqMY2naGaBRTjCtMzR9QUGxvdi	Guest Player		2025-10-08 07:01:04.964	2025-10-08 07:01:04.964	\N	f	\N	\N	\N
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: courts courts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courts
    ADD CONSTRAINT courts_pkey PRIMARY KEY (id);


--
-- Name: guests guests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: rsvps rsvps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rsvps
    ADD CONSTRAINT rsvps_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: set_scores set_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.set_scores
    ADD CONSTRAINT set_scores_pkey PRIMARY KEY (id);


--
-- Name: sets sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sets
    ADD CONSTRAINT sets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: courts_session_id_court_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX courts_session_id_court_number_key ON public.courts USING btree (session_id, court_number);


--
-- Name: courts_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courts_session_id_idx ON public.courts USING btree (session_id);


--
-- Name: guests_added_by_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guests_added_by_id_idx ON public.guests USING btree (added_by_id);


--
-- Name: guests_court_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guests_court_id_idx ON public.guests USING btree (court_id);


--
-- Name: guests_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guests_session_id_idx ON public.guests USING btree (session_id);


--
-- Name: notifications_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_created_at_idx ON public.notifications USING btree (created_at);


--
-- Name: notifications_user_id_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_id_read_idx ON public.notifications USING btree (user_id, read);


--
-- Name: rsvps_court_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rsvps_court_id_idx ON public.rsvps USING btree (court_id);


--
-- Name: rsvps_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rsvps_session_id_idx ON public.rsvps USING btree (session_id);


--
-- Name: rsvps_session_id_user_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX rsvps_session_id_user_id_key ON public.rsvps USING btree (session_id, user_id);


--
-- Name: rsvps_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rsvps_user_id_idx ON public.rsvps USING btree (user_id);


--
-- Name: sessions_created_by_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_created_by_id_idx ON public.sessions USING btree (created_by_id);


--
-- Name: sessions_date_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_date_time_idx ON public.sessions USING btree (date, "time");


--
-- Name: set_scores_guest_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX set_scores_guest_id_idx ON public.set_scores USING btree (guest_id);


--
-- Name: set_scores_set_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX set_scores_set_id_idx ON public.set_scores USING btree (set_id);


--
-- Name: set_scores_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX set_scores_user_id_idx ON public.set_scores USING btree (user_id);


--
-- Name: sets_court_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sets_court_id_idx ON public.sets USING btree (court_id);


--
-- Name: sets_created_by_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sets_created_by_id_idx ON public.sets USING btree (created_by_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: courts courts_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courts
    ADD CONSTRAINT courts_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: guests guests_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: guests guests_court_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_court_id_fkey FOREIGN KEY (court_id) REFERENCES public.courts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: guests guests_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rsvps rsvps_court_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rsvps
    ADD CONSTRAINT rsvps_court_id_fkey FOREIGN KEY (court_id) REFERENCES public.courts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rsvps rsvps_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rsvps
    ADD CONSTRAINT rsvps_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rsvps rsvps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rsvps
    ADD CONSTRAINT rsvps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: set_scores set_scores_guest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.set_scores
    ADD CONSTRAINT set_scores_guest_id_fkey FOREIGN KEY (guest_id) REFERENCES public.guests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: set_scores set_scores_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.set_scores
    ADD CONSTRAINT set_scores_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.sets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: set_scores set_scores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.set_scores
    ADD CONSTRAINT set_scores_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sets sets_court_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sets
    ADD CONSTRAINT sets_court_id_fkey FOREIGN KEY (court_id) REFERENCES public.courts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sets sets_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sets
    ADD CONSTRAINT sets_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict eSQCujzN6D5Yuwz2HZBtHVewwznkotxOVjvu80FpVBvkp6Skr7GOqLV23gFZS46

